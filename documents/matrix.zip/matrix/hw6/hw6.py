# version code 988
# Please fill out this stencil and submit using the provided submission script.

from matutil import *
from GF2 import one
from vec import Vec
from vecutil import zero_vec



## Problem 1
# Write each matrix as a list of row lists

echelon_form_1 = [[ 1,2,0,2,0 ],
                  [ 0,1,0,3,4 ],
                  [ 0,0,2,3,4 ],
                  [ 0,0,0,2,0 ],
                  [ 0,0,0,0,4 ]]

echelon_form_2 = [[ 0,4,3,4,4 ],
                  [ 0,0,4,2,0],
                  [ 0,0,0,0,1   ],
                  [ 0,0,0,0,0   ]]

echelon_form_3 = [[ 1,0,0,1 ],
                  [ 0,0,0,1   ],
                  [ 0,0,0,0   ]]

echelon_form_4 = [[1,0,0,0 ],
                  [ 0,1,0,0     ],
                  [ 0,0,0,0   ],
                  [  0,0,0,0   ]]



## Problem 2
def is_echelon(A):
    '''
    Input:
        - A: a list of row lists
    Output:
        - True if A is in echelon form
        - False otherwise
    Examples:
        >>> is_echelon([[1,1,1],[0,1,1],[0,0,1]])
        True
        >>> is_echelon([[0,1,1],[0,1,0],[0,0,1]])
        False
    '''
    first_nonzero_index = list()
    bignum = len(A[0])
    for i in range(len(A)):
        for j in range(len(A[i])):                
            if A[i][j] != 0:
                first_nonzero_index.append(j)
                break
            elif j == len(A[i]) - 1:
                first_nonzero_index.append(bignum)
                bignum = bignum + 1
    return sorted( first_nonzero_index) ==  first_nonzero_index and len(set(first_nonzero_index)) == len(first_nonzero_index)
    
                    
    



## Problem 3
# Give each answer as a list

echelon_form_vec_a = [1,0,3,0]
echelon_form_vec_b = [-3,0,-2,3]
echelon_form_vec_c = [-5,0,2,0,2]



## Problem 4
# If a solution exists, give it as a list vector.
# If no solution exists, provide "None".

solving_with_echelon_form_a = None
solving_with_echelon_form_b = [21,0,2,0,0]

'''
def myprocedure(rowlist,label_list,b):
    leading_rowlist=[]
    zeros_rowindex = []
    for i in range(len(rowlist)):
        for j in range(len(label_list)):
            if label_list[j] in rowlist[i].f.keys() and rowlist[i].f[label_list[j]] == one:
                leading_rowlist.append((i,j))
                break
            elif j == len(label_list) - 1: # row with all zeros
                zeros_rowindex.append(i)
    adj_rowlist = [rowlist[r] for (r,c) in leading_rowlist]
    adj_b = [b[r] for (r,c) in leading_rowlist ]
    leading_rowlist.sort(key=lambda tup:tup[1])
    adj_col = [label_list[c] for (r,c) in leading_rowlist]
    adj_rowlist2 = []
    for i in range(len(adj_rowlist)):
        temp = adj_rowlist[i].f.copy()
        for (k,v) in adj_rowlist[i].f.items():
            if k not in adj_col:
                temp.pop(k,None)
        vv = Vec(set(adj_col),temp)
        adj_rowlist2.append(vv)
    D = set(adj_col)
    x = zero_vec(D)
    echelon_rowlist=[]
    echelon_b2=[]
    for i in range(len(adj_col)):
        for j in range(len(adj_rowlist2)):
            if adj_rowlist2[j].f[adj_col[i]] == one and adj_rowlist2[j] not in echelon_rowlist:
                echelon_rowlist.append(adj_rowlist2[j])
                echelon_b2.append(adj_b[j])
                break
    return [echelon_rowlist,adj_col,echelon_b2]
'''
## Problem 5
def echelon_solve(rowlist, label_list, b):
    '''
    Input:
        - rowlist: a list of Vecs
        - label_list: a list of labels establishing an order on the domain of
                      Vecs in rowlist
        - b: a vector (represented as a list)
    Output:
        - Vec x such that rowlist * x is b
    >>> D = {'A','B','C','D','E'}
    >>> U_rows = [Vec(D, {'A':one, 'E':one}), Vec(D, {'B':one, 'E':one}), Vec(D,{'C':one})] 
    >>> b_list = [one,0,one]
    >>> cols = ['A', 'B', 'C', 'D', 'E']
    >>> echelon_solve(U_rows, cols, b_list)
    Vec({'B', 'C', 'A', 'D', 'E'},{'B': 0, 'C': one, 'A': one})

    my sample
    >>> from solver import solve
    >>> solve.__calls__ = 0
    >>> from GF2 import one
    >>> label_list=cols = ['A', 'B', 'C', 'D', 'E']
    >>> D = set(cols)
    
    >>> rowlist=U_rows = [Vec(D,{'E': one, 'D': one, 'A': 0, 'C': 0, 'B': one}), Vec(D,{'E': 0, 'D': one, 'A': 0, 'C': 0, 'B': 0}), Vec(D,{'E': 0, 'D': 0, 'A': one, 'C': one, 'B': 0}), Vec(D,{'E': 0, 'D': 0, 'A': 0, 'C': 0, 'B': 0})]
    >>> b=b_list = [0, 0, one, 0]
    >>> u = echelon_solve(U_rows, cols, b_list)

    >>> rowlist=U_rows = [Vec(D, {'A':one, 'C':one}), Vec(D, {'C':one, 'E':one}), Vec(D,{'D':one})]
    >>> b=b_list = [one, one, one]
    >>> u = echelon_solve(U_rows, cols, b_list)
   
    '''
    leading_rowlist=[]
    zeros_rowindex = []
    for i in range(len(rowlist)):
        for j in range(len(label_list)):
            if label_list[j] in rowlist[i].f.keys() and rowlist[i].f[label_list[j]] == one:
                leading_rowlist.append((i,j))
                break
            elif j == len(label_list) - 1: # row with all zeros
                zeros_rowindex.append(i)
    adj_rowlist = [rowlist[r] for (r,c) in leading_rowlist]
    adj_b = [b[r] for (r,c) in leading_rowlist ]
    leading_rowlist.sort(key=lambda tup:tup[1])
    adj_col = [label_list[c] for (r,c) in leading_rowlist]
    adj_rowlist2 = []
    for i in range(len(adj_rowlist)):
        temp = adj_rowlist[i].f.copy()
        for (k,v) in adj_rowlist[i].f.items():
            if k not in adj_col:
                temp.pop(k,None)
        vv = Vec(set(adj_col),temp)
        adj_rowlist2.append(vv)
    D = set(adj_col)
    x = zero_vec(D)
    echelon_rowlist=[]
    echelon_b2=[]
    for i in range(len(adj_col)):
        for j in range(len(adj_rowlist2)):
            if adj_rowlist2[j].f[adj_col[i]] == one and adj_rowlist2[j] not in echelon_rowlist:
                echelon_rowlist.append(adj_rowlist2[j])
                echelon_b2.append(adj_b[j])
                break
    #[adj_rowlist2,adj_col,adj_b] = myprocedure(rowlist,label_list,b)
    adj_rowlist2 = echelon_rowlist
    adj_b = echelon_b2
    D = adj_rowlist2[0].D
    x = zero_vec(D)
    for j in reversed(range(len(D))):
        c = adj_col[j]
        row = adj_rowlist2[j]
        x[c] = (adj_b[j] - x*row)/row[c]
    xx = zero_vec(rowlist[0].D)
    for k in x.f.keys():
        xx.f[k] = x.f[k]
    return xx
    
    
    
    



## Problem 6
rowlist = [Vec({'A','B','C','D'},{'A':one,'B':one,'D':one}),Vec({'A','B','C','D'},{'B':one}),Vec({'A','B','C','D'},{'C':one}),Vec({'A','B','C','D'},{'D':one})]    # Provide as a list of Vec instances
label_list = ['A','B','C','D'] # Provide as a list
b = [ one,one,0,0 ]          # Provide as a list



## Problem 7
null_space_rows_a = {3,4} # Put the row numbers of M from the PDF



## Problem 8
null_space_rows_b = {4}



## Problem 9
# Write each vector as a list
closest_vector_1 = [1.6,3.2]
closest_vector_2 = [0,1,0]
closest_vector_3 = [3,2,1,-4]



## Problem 10
# Write each vector as a list

project_onto_1 = [2,0]
projection_orthogonal_1 = [0,1]

project_onto_2 = [-1/6,-1/3,1/6]
projection_orthogonal_2 = [7/6,4/3,23/6]

project_onto_3 = [1,1,4]
projection_orthogonal_3 = [0,0,0]



## Problem 11
norm1 = 3
norm2 = 4
norm3 = 1

