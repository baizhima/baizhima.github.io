voting_data = list(open("voting_record_dump109.txt"))

## Task 1

def create_voting_dict():
    
    """
    Input: None (use voting_data above)
    Output: A dictionary that maps the last name of a senator
            to a list of numbers representing the senator's voting
            record.
    Example: 
        >>> create_voting_dict()['Clinton']
        [-1, 1, 1, 1, 0, 0, -1, 1, 1, 1, 1, 1, 1, 1, -1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
         -1, 1, -1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, -1, 1, 1, 1, 1, -1, 1, 1, 1]

    This procedure should return a dictionary that maps the last name
    of a senator to a list of numbers representing that senator's
    voting record, using the list of strings from the dump file (strlist). You
    will need to use the built-in procedure int() to convert a string
    representation of an integer (e.g. '1') to the actual integer
    (e.g. 1).

    You can use the split() procedure to split each line of the
    strlist into a list; the first element of the list will be the senator's
    name, the second will be his/her party affiliation (R or D), the
    third will be his/her home state, and the remaining elements of
    the list will be that senator's voting record on a collection of bills.
    A "1" represents a 'yea' vote, a "-1" a 'nay', and a "0" an abstention.

    The lists for each senator should preserve the order listed in voting data. 
    """
    voting_dict = {};
    for line in voting_data:
        buf = line.split()
        temp = buf[3:len(buf)]
        for i in range(len(temp)):
            temp[i] = int(temp[i])
        voting_dict[buf[0]]=temp
    return voting_dict
    

## Task 2

def policy_compare(sen_a, sen_b, voting_dict):
    """
    Input: last names of sen_a and sen_b, and a voting dictionary mapping senator
           names to lists representing their voting records.
    Output: the dot-product (as a number) representing the degree of similarity
            between two senators' voting policies
    Example:
        >>> voting_dict = {'Fox-Epstein':[-1,-1,-1,1],'Ravella':[1,1,1,1]}
        >>> policy_compare('Fox-Epstein','Ravella', voting_dict)
        -2
    """
    vec1 = voting_dict[sen_a];
    vec2 = voting_dict[sen_b];
    sum = 0;
    for i in range(len(vec1)):
        sum += vec1[i]*vec2[i]
    return sum


## Task 3

def most_similar(sen, voting_dict):
    """
    Input: the last name of a senator, and a dictionary mapping senator names
           to lists representing their voting records.
    Output: the last name of the senator whose political mindset is most
            like the input senator (excluding, of course, the input senator
            him/herself). Resolve ties arbitrarily.
    Example:
        >>> vd = {'Klein': [1,1,1], 'Fox-Epstein': [1,-1,0], 'Ravella': [-1,0,0]}
        >>> most_similar('Klein', vd)
        'Fox-Epstein'

    Note that you can (and are encouraged to) re-use you policy_compare procedure.
    """
    max_score = -100
    similar_sen = ''
    for k in voting_dict.keys():
        if k==sen:
            continue
        if policy_compare(sen,k,voting_dict) > max_score:
            similar_sen = k
            max_score = policy_compare(sen,k,voting_dict)
    return similar_sen
    

## Task 4

def least_similar(sen, voting_dict):
    """
    Input: the last name of a senator, and a dictionary mapping senator names
           to lists representing their voting records.
    Output: the last name of the senator whose political mindset is least like the input
            senator.
    Example:
        >>> vd = {'Klein': [1,1,1], 'Fox-Epstein': [1,-1,0], 'Ravella': [-1,0,0]}
        >>> least_similar('Klein', vd)
        'Ravella'
    """
    min_score = 100
    least_sen = ''
    for k in voting_dict.keys():
        if k==sen:
            continue
        if policy_compare(sen,k,voting_dict) < min_score:
            least_sen = k
            min_score = policy_compare(sen,k,voting_dict)
    return least_sen
    
    

## Task 5

most_like_chafee    = 'Jeffords'
least_like_santorum = 'Feingold' 



# Task 6

def find_average_similarity(sen, sen_set, voting_dict):
    """
    Input: the name of a senator, a set of senator names, and a voting dictionary.
    Output: the average dot-product between sen and those in sen_set.
    Example:
        >>> vd = {'Klein': [1,1,1], 'Fox-Epstein': [1,-1,0], 'Ravella': [-1,0,0]}
        >>> find_average_similarity('Klein', {'Fox-Epstein','Ravella'}, vd)
        -0.5
    """
    sum = 0
    for senate in sen_set:
        sum += policy_compare(sen, senate, voting_dict)
    sum /= len(sen_set)
    return sum

most_average_Democrat = ... # give the last name (or code that computes the last name)


# Task 7

def find_average_record(sen_set, voting_dict):
    """
    Input: a set of last names, a voting dictionary
    Output: a vector containing the average components of the voting records
            of the senators in the input set
    Example: 
        >>> voting_dict = {'Klein': [-1,0,1], 'Fox-Epstein': [-1,-1,-1], 'Ravella': [0,0,1]}
        >>> find_average_record({'Fox-Epstein','Ravella'}, voting_dict)
        [-0.5, -0.5, 0.0]
    """
    for v in voting_dict.values():
        vec_length = len(v)    
    total_vec = list()
    for i in range(vec_length):
        total_vec.append(0)
    for senate in sen_set:
        for i in range(vec_length):
            total_vec[i] += voting_dict[senate][i]
    for i in range(vec_length):
        total_vec[i] /= len(sen_set)
            
    return total_vec

average_Democrat_record = [-0.162791, -0.232558, 1, 0.837209, 0.976744, -0.139535, -0.953488, 0.813953, 0.976744, 0.976744, 0.906977, 0.767442, 0.674419, 0.976744, -0.511628, 0.930233, 0.953488, 0.976744, -0.395349, 0.976744, 1, 1, 1, 0.953488, -0.488372, 1, -0.325581, -0.0697674, 0.976744, 0.860465, 0.976744, 0.976744, 1, 1, 0.976744, -0.348837, 0.976744, -0.488372, 0.232558, 0.883721, 0.44186, 0.906977, -0.906977, 1, 0.906977, -0.302326] # (give the vector)


# Task 8

def bitter_rivals(voting_dict):
    """
    Input: a dictionary mapping senator names to lists representing
           their voting records
    Output: a tuple containing the two senators who most strongly
            disagree with one another.
    Example: 
        >>> voting_dict = {'Klein': [-1,0,1], 'Fox-Epstein': [-1,-1,-1], 'Ravella': [0,0,1]}
        >>> bitter_rivals(voting_dict)
        ('Fox-Epstein', 'Ravella')
    """
    min_val = 1000
    pairs = ('','')
    for k1 in voting_dict.keys():
        for k2 in voting_dict.keys():
            if k1 == k2:
                continue
            else:
                 if policy_compare(k1, k2, voting_dict) < min_val:
                     min_val = policy_compare(k1, k2, voting_dict)
                     pairs = (k1,k2)
        
    return pairs

