from orthogonalization import aug_orthogonalize,orthogonalize
from mat import Mat
from matutil import listlist2mat,coldict2mat,mat2coldict
from math import sqrt, pi,pow
def orthonormalize(L):
    '''
    Input: a list L of linearly independent Vecs
    Output: A list T of orthonormal Vecs such that for all i in [1, len(L)],
            Span L[:i] == Span T[:i]
    >>> inlist = [[4,3,1,2],[8,9,-5,-5],[10,1,-1,5]]
    >>> outlist = [
    [0.73,0.55,0.18,0.37],
    [0.19,0.40,-0.57,-0.69],
    [0.53, -0.65, -0.51,0.18]]

    >>> vlist = [list2vec(x) for x in inlist]
    >>> olist = [list2vec(x) for x in outlist]

    >>> import pprint

    >>> a = orthonormalization.orthonormalize(vlist)
    >>> pprint.pprint(a)
    >>> print('should be, very similar to')
    >>> pprint.pprint(olist)
    '''
    ortho_L = orthogonalize(L)
    for i in range(len(ortho_L)):
        norm = sqrt(ortho_L[i]*ortho_L[i])
        if norm < pow(10,-20):
            ortho_L[i].f={}
        else:
            ortho_L[i] = ortho_L[i]/norm
    return ortho_L
    


def aug_orthonormalize(L):
    '''
    Input:
        - L: a list of Vecs
    Output:
        - A pair Qlist, Rlist such that:
            * coldict2mat(L) == coldict2mat(Qlist) * coldict2mat(Rlist)
            * Qlist = orthonormalize(L)
    '''
    vstarlist, sigma_vecs = aug_orthogonalize(L)
    Qlist = orthonormalize(L)
    
    Rlist = coldict2mat(sigma_vecs)
    for i in range(len(Rlist.D[0])):
        norm = sqrt(vstarlist[i]*vstarlist[i])
        for j in range(len(Rlist.D[1])):
            Rlist.f[(i,j)] = norm*Rlist.f[(i,j)]
                       
    Rlist = mat2coldict(Rlist)
    return Qlist,Rlist
