/*
 * File: allocator.c
 * Author: Siyu Yang <siyu>, Shan Lu <shanlu>
 * ----------------------
 */



#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <error.h>
#include <assert.h>
#include "allocator.h"
#include "segment.h"


// Heap blocks are required to be aligned to 8-byte boundary
#define ALIGNMENT 8
#define WSIZE       4   // Word and header/footer size (bytes)
#define DSIZE     8   // Double word size (bytes)
#define PAGESIZE (1 << 12) // Extend heap by this amount(4MB)

static void* heap_start;
static void* heap_end;
static void* last_stop;




static inline unsigned int pack(unsigned int size, unsigned int allocated) {
    return (size | allocated);
}

static inline void write_overhead(void *overhead_ptr, unsigned int val) {
    *(unsigned int *)overhead_ptr = val;
}

static inline unsigned int get_size(void *overhead_ptr) {
    return *(unsigned int *)overhead_ptr & ~0x7;
}

static inline bool is_allocated(void *overhead_ptr) {
    return *(unsigned int *)overhead_ptr & 0x1;
}

static inline void* get_header(void *base_ptr) {
    return (char *)base_ptr - WSIZE;
}

static inline void* get_footer(void *base_ptr) {
    return (char *)base_ptr + get_size(get_header(base_ptr)) - DSIZE;
}

static inline void* get_next_base_ptr(void *base_ptr) {
    return (char *)base_ptr + get_size(get_header(base_ptr));
}

static inline void* get_prev_base_ptr(void* base_ptr) {
    unsigned int prev_size = get_size(((char *)base_ptr - DSIZE));
    return (char *)base_ptr - prev_size;
}




static inline void place(void *base_ptr, size_t actual_size) {

    size_t capacity_size = get_size(get_header(base_ptr)); // get the size of the current block by reading the header

    // if there are any remaining space that's bigger than the minimum size of a block, set the remaining as a free block
    if (capacity_size - actual_size >= 2 * DSIZE) {
        write_overhead(get_header(base_ptr), pack(actual_size, 1));
        write_overhead(get_footer(base_ptr), pack(actual_size, 1));
        base_ptr = get_next_base_ptr(base_ptr);
        write_overhead(get_header(base_ptr), pack(capacity_size - actual_size, 0));
        write_overhead(get_footer(base_ptr), pack(capacity_size - actual_size, 0));
    }
    // unavoidable fragmentation if the remaining space is not enough for any block
    else {
        write_overhead(get_header(base_ptr), pack(capacity_size, 1));
        write_overhead(get_footer(base_ptr), pack(capacity_size, 1));
    }
}

int myinit()
{
    init_heap_segment(0); // reset heap segment to empty, no pages allocated
    if ((heap_start = extend_heap_segment(1)) == NULL)
        return -1;
    write_overhead(heap_start, 0);  // first 4 bytes unused
    // set the prologue and the epilogue to 'allocated' to prevent coalescing beyond the two ends of the heap
    write_overhead((char *)heap_start + 1 * WSIZE, pack(DSIZE, 1)); // initialize prologue header
    write_overhead((char *)heap_start + 2 * WSIZE, pack(DSIZE, 1)); // initialize prologue footer
    void *epilogue_ptr = (char *)heap_start + PAGESIZE ;
    assert((unsigned int)epilogue_ptr % 8 == 0);
    write_overhead(get_header(epilogue_ptr), pack(0, 1));     // initialize epilogue header (epilogue has no footer)
    heap_end = epilogue_ptr;
    heap_start = (char *)heap_start + (4 * WSIZE);  // points to the base_ptr of the first actual block (not yet malloc'ed)
    last_stop = heap_start;
    void *base_ptr = heap_start;
    write_overhead(get_header(base_ptr), pack(PAGESIZE - 4 * WSIZE, 0));
    write_overhead(get_footer(base_ptr), pack(PAGESIZE - 4 * WSIZE, 0));
    return 0;
}


static inline void *find_fit(size_t actual_size) {

    unsigned int current_size;
    for (void* base_ptr = last_stop; (current_size = get_size(get_header(base_ptr))) > 0; base_ptr = get_next_base_ptr(base_ptr)) {
        if (!is_allocated(get_header(base_ptr)) && actual_size <= current_size) {
            return base_ptr;
        }
    }

    return NULL;
}

void* coalesce(void *base_ptr) {

    unsigned int size = get_size(get_header(base_ptr));
    void* next_base_ptr = get_next_base_ptr(base_ptr);
    void* prev_base_ptr = get_prev_base_ptr(base_ptr);
    bool next_allocated = is_allocated(get_header(next_base_ptr));
    bool prev_allocated = is_allocated(get_footer(prev_base_ptr));
    // case 1: prev allocated, next allocated
    if (prev_allocated && next_allocated) {
        return base_ptr;
    }
    // case 2: prev allocated, next free
    else if (prev_allocated && !next_allocated){
        size += get_size(get_header(next_base_ptr));
        write_overhead(get_header(base_ptr), pack(size, 0)); // must first write the header, because get_footer relies on header's size to find
        write_overhead(get_footer(base_ptr), pack(size, 0));
    }
    // case 3: prev free, next allocated
    else if (!prev_allocated && next_allocated) {
        size += get_size(get_footer(prev_base_ptr));
        write_overhead(get_header(prev_base_ptr), pack(size, 0));
        write_overhead(get_footer(prev_base_ptr), pack(size, 0));
        base_ptr = prev_base_ptr;
    }
    // case 4: prev free, next free
    else {
        if (prev_base_ptr == base_ptr) return base_ptr; // epilogue case
        size += get_size(get_header(next_base_ptr)) + get_size(get_footer(prev_base_ptr));
        write_overhead(get_header(prev_base_ptr), pack(size, 0));
        write_overhead(get_footer(prev_base_ptr), pack(size, 0));
        base_ptr = prev_base_ptr;
    }
    last_stop = base_ptr;
    return base_ptr;
}


void* get_more_space(unsigned int actual_size) {
    // because the old epilogue will be overwritten with header, we'll have enough space for the new epilogue
    int extend_npages = (actual_size + (PAGESIZE - 1)) / PAGESIZE ;
    void *base_ptr = extend_heap_segment(extend_npages);
    void *page_end = (char*)base_ptr + extend_npages * PAGESIZE;
    if (!base_ptr)
        return NULL;

    // set the remaining space as a free block
    // only do that when the remaining space is large enough to contain the smallest block: 16 bytes
    void *next_free_base_ptr = (char *)base_ptr + actual_size;
    if ((char*)page_end - (char*)next_free_base_ptr >= 2 * DSIZE) {
        write_overhead(get_header(base_ptr), pack(actual_size, 0)); // overwrties previous epilogue with the header of the new block
        write_overhead(get_footer(base_ptr), pack(actual_size, 0)); // writes the new block's footer

        unsigned int next_free_size = extend_npages * PAGESIZE - actual_size;
        write_overhead(get_header(next_free_base_ptr), pack(next_free_size, 0)); // pack might be unnecessary
        write_overhead(get_footer(next_free_base_ptr), pack(next_free_size, 0));
    }
    else {
        write_overhead(get_header(base_ptr), pack(extend_npages * PAGESIZE, 0)); // overwrties previous epilogue with the header of the new block
        write_overhead(get_footer(base_ptr), pack(extend_npages * PAGESIZE, 0)); // writes the new block's footer
    }

    // update epilogue
    void *epilogue_ptr = (char*)base_ptr + PAGESIZE * extend_npages;
    write_overhead(get_header(epilogue_ptr), pack(0, 1));
    heap_end = epilogue_ptr;
    return coalesce(base_ptr); // coalsece with possible empty but small chunks at the old end
}


void *mymalloc(size_t requested_size)
{
    size_t actual_size;           // Adjusted block size
    char*  base_ptr;

    // Ignore spurious requests
    if (requested_size == 0)
        return NULL;

    // Adjust block size to include overhead and alignment reqs.

    if (requested_size <= DSIZE)
        actual_size = 2 * DSIZE; // smallest possible block is one of 18 (header + footer + 8-aligned content)
    else {
        actual_size = DSIZE * ((requested_size + (DSIZE) + (DSIZE - 1)) / DSIZE); // +(DSIZE) to house the header and footer
    }


    // Search the free list for a fit
    base_ptr = find_fit(actual_size);
    if (base_ptr != NULL) {
        place(base_ptr, actual_size);
        last_stop = base_ptr;
        return base_ptr;
    }

    // No fit found. Get more memory and place the block
    base_ptr = get_more_space(actual_size);
    if(base_ptr == NULL) return NULL;

    place(base_ptr, actual_size);
    return base_ptr;
}


void myfree(void *base_ptr)
{
    if (base_ptr == NULL)
        return;
    unsigned int size = get_size(get_header(base_ptr));
    write_overhead(get_header(base_ptr), pack(size, 0));
    write_overhead(get_footer(base_ptr), pack(size, 0));
    coalesce(base_ptr);
}


void *myrealloc(void *old_base_ptr, size_t newsz)
{
    if (newsz == 0 || old_base_ptr > heap_end)
        return NULL;
    if (old_base_ptr != NULL && newsz == 0)
        myfree(old_base_ptr);
    if (old_base_ptr == NULL)
        return mymalloc(newsz);

    // find the actual size of the required block
    if (newsz <= DSIZE)
        newsz = 2 * DSIZE;
    else {
        newsz = DSIZE * ((newsz + (DSIZE) + (DSIZE - 1)) / DSIZE); // +(DSIZE) to house the header and footer
    }

    unsigned int old_size = get_size(get_header(old_base_ptr));

    // case 1: resizing to a smaller size
    if (newsz <= old_size) {
        return old_base_ptr; // once realloc'ed, it's likely that it's going to be realloc'ed again
    }

    // case 2: enough free space behind current block
    void *next_base_ptr = get_next_base_ptr(old_base_ptr);
    bool next_allocated = is_allocated(get_header(next_base_ptr));
    unsigned int next_size = get_size(get_header(next_base_ptr)); // TODO get_size only if not allocated

    if (!next_allocated && (old_size + next_size >= newsz)) {
        write_overhead(get_header(old_base_ptr), pack(old_size + next_size, 1));
        write_overhead(get_footer(old_base_ptr), pack(old_size + next_size, 1));
        last_stop = old_base_ptr;
        return old_base_ptr;
    }

    // case 3: enough free space before current block
    void *prev_base_ptr = get_prev_base_ptr(old_base_ptr);
    bool prev_allocated = is_allocated(get_header(prev_base_ptr));
    unsigned int prev_size = get_size(get_header(prev_base_ptr));

    if (!prev_allocated && (old_size + prev_size >= newsz)) {

        memmove(prev_base_ptr, old_base_ptr, old_size - DSIZE);
        write_overhead(get_header(prev_base_ptr), pack(old_size + prev_size, 1));
        write_overhead(get_footer(prev_base_ptr), pack(old_size + prev_size, 1));
        last_stop = prev_base_ptr;
        return prev_base_ptr;
    }

    // case 4: we have to find another space
    void *new_base_ptr = mymalloc(newsz);
    if(new_base_ptr == NULL) {
        return NULL;
    }
    memmove(new_base_ptr, old_base_ptr, old_size - DSIZE);

    myfree(old_base_ptr);
    return new_base_ptr;
}


bool validate_heap()
{
   /*
    printf("epilogue = %p:\n",heap_end);
    printf("epilogue info: size = %d, allocated = %d, pointer %p\n", get_size(get_header(heap_end)), is_allocated(get_header(heap_end)), heap_end);
    void* base_ptr = heap_start;
    while (true) {
        unsigned int size = get_size(get_header(base_ptr));
        bool allocated = is_allocated(get_header(base_ptr));
        if (size == 0 && allocated == 1)
            break;
        printf("(base_ptr = %p, size = %#x, allocated = %d, next = %p)\n",
            base_ptr, size, (unsigned int)allocated, get_next_base_ptr(base_ptr));
        base_ptr = get_next_base_ptr(base_ptr);
    }
     */
    return true;
}