/* $begin tinymain */
/*
* tiny.c - A simple, iterative HTTP/1.0 Web server that uses the
*     GET method to serve static and dynamic content.
*/
#include "csapp.h"



void doit(int fd);
void read_requesthdrs(rio_t *rp, char* hostname, char *req_headers);
void parse_uri(char *uri,char *hostname, char *port, char *remainder);
void clienterror(int fd, char *cause, char *errnum,
                char *shortmsg, char *longmsg);


static const char *user_agent_hdr = "User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:10.0.3) Gecko/20120305 Firefox/10.0.3\r\n";
static const char *accept_hdr = "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8\r\n";
static const char *accept_encoding_hdr = "Accept-Encoding: gzip, deflate\r\n";


int main(int argc, char **argv)
{
    int listenfd, connfd;
    char hostname[MAXLINE], port[MAXLINE];
    socklen_t clientlen;
    struct sockaddr_storage clientaddr;

/* Check command line args */
    if (argc != 2) {
       fprintf(stderr, "usage: %s <port>\n", argv[0]);
       exit(1);
   }
   Signal(SIGPIPE, SIG_IGN); // the program will not terminate by SIGPIPE
   listenfd = Open_listenfd(argv[1]);
   while (1) {
        clientlen = sizeof(clientaddr);
        connfd = Accept(listenfd, (SA *)&clientaddr, &clientlen); //line:netp:tiny:accept
        Getnameinfo((SA *) &clientaddr, clientlen, hostname, MAXLINE,
                    port, MAXLINE, 0);
        printf("Accepted connection from (%s, %s)\n", hostname, port);
        doit(connfd);                                             //line:netp:tiny:doit
        Close(connfd);                                            //line:netp:tiny:close
    }
}
/* $end tinymain */

/*
* doit - handle one HTTP request/response transaction
*/
/* $begin doit */
void doit(int fd)
{

    char buf[MAXLINE], method[MAXLINE], uri[MAXLINE], version[MAXLINE];
    char hostname[MAXLINE],port[MAXLINE], remainders[MAXLINE] ;
    char req_headers[MAXLINE], req_line[MAXLINE], req_overall[MAXLINE];
    rio_t rio_client, rio_server;

    int proxy_server_fd; // proxy serves as a client


    req_line[0] = req_headers[0] = req_overall[0] = '\0';
    hostname[0] = '\0';
/* Read request line and headers */
    Rio_readinitb(&rio_client, fd);
    if (!Rio_readlineb(&rio_client, buf, MAXLINE))  //line:netp:doit:readrequest
        return;
    printf("%s", buf);
    sscanf(buf, "%s %s %s", method, uri, version);       //line:netp:doit:parserequest
    if (strcasecmp(method, "GET")) {                     //line:netp:doit:beginrequesterr
        clienterror(fd, method, "501", "Not Implemented",
            "Tiny does not implement this method");
        return;
    }                                                    //line:netp:doit:endrequesterr


    /* Parse URI from GET request */
    parse_uri(uri, hostname, port, remainders);       //line:netp:doit:staticcheck

    sprintf(req_line, "%sGET %s HTTP/1.0\r\n", req_line, remainders);     // only HTTP/1.0 and GET method are supported
    read_requesthdrs(&rio_client, hostname, req_headers);                //line:netp:doit:readrequesthdrs
    strcpy(req_overall, req_line);
    strcat(req_overall, req_headers);

    // proxy connects with server
    printf("Try clientfd..hostname = %s, port = %s \n", hostname, port);

    if ((proxy_server_fd = Open_clientfd(hostname, port)) < 0) {
        clienterror(fd, "GET", "404", "Not found",
                "Requested URL could not be found");
        close(fd);
        return;
    }

    Rio_readinitb(&rio_server, proxy_server_fd);

    
    if (rio_writen(proxy_server_fd, req_overall, strlen(req_overall)) < 0) {
        if (errno != EPIPE)
            close(fd);
        return;
    }

    int n;
    while ((n = Rio_readlineb(&rio_server, buf, MAXLINE)) != 0) {
        printf("%s", buf);
        if (rio_writen(fd, buf, n) < 0) {
            if (errno != EPIPE)
                close(fd);
            return;
        }
        
    }

    Close(proxy_server_fd);

}
/* $end doit */

/*
 * Function: read_requesthdrs - read HTTP request headers
 * If specified in headers, then we set Host header according to browser's original host values.
 * By default, the Host value is parsed from GET request line
 *
 */
void read_requesthdrs(rio_t *rp, char *host, char *headers)
{
    char buf[MAXLINE];
    char additionals[MAXLINE];
    char host_hdrs[MAXLINE];
    headers[0] = additionals[0] = '\0';


    while (1) {
        Rio_readlineb(rp, buf, MAXLINE);
        if (strcmp(buf, "\r\n") == 0) break;

        if (strstr(buf, "Host: ")) {
            char *pBegin = buf + strlen("Host: ");
            char *pEnd = pBegin + 1;
            while (*pEnd != '\r')
                pEnd += 1;
            int host_len = pEnd - pBegin;
            strncpy(host_hdrs, pBegin, host_len);
            host_hdrs[host_len] = '\0';
            continue;
        }
        if (strstr(buf, "User-Agent: ") == buf || strstr(buf, "Accept: ") == buf
            || strstr(buf, "Accept: ") == buf || strstr(buf, "Accept-Encoding: ") == buf
            || strstr(buf, "Connection: ") == buf || strstr(buf, "Proxy-Connection: ") == buf)
            continue;
        sprintf(additionals, "%s%s", additionals, buf);

    }

    sprintf(headers, "%sHost: %s\r\n", headers, host_hdrs);
    sprintf(headers, "%s%s", headers, user_agent_hdr);
    sprintf(headers, "%s%s", headers, accept_hdr);
    sprintf(headers, "%s%s", headers, accept_encoding_hdr);
    sprintf(headers, "%sConnection: close\r\n", headers);
    sprintf(headers, "%sProxy-Connection: close\r\n", headers);
    sprintf(headers, "%s%s\r\n", headers, additionals);

    printf("[read_requesthdrs]header request:\n%s",headers);

}
/* $end read_requesthdrs */

/*
* parse_uri - parse URI into filename and CGI args
*             return port number in char* (default "80")
*/
/* $begin parse_uri */
void parse_uri(char *uri, char *hostname, char *port, char *remainders)
{
    strcpy(port, "99999");
    char *uri_ptr = uri;
    if (strncasecmp(uri,"http://", 7) == 0)
        uri_ptr = uri_ptr + 7;

    int count = 0;
    while (1) {
        if (*uri_ptr == '\0' || *uri_ptr == '/') break;
        if (*uri_ptr == ':') { // extract port number
            char *port_begin = uri_ptr + 1;
            char *port_end = port_begin;
            while (*port_end != '\0' && *port_end != '/')
                port_end++;
            int port_len = port_end - port_begin;
            strncpy(port, port_begin, port_len);
            *(port + port_len) = '\0';
            uri_ptr = port_end;
            continue;
        }
        hostname[count++] = *uri_ptr;
        uri_ptr += 1;
    }
    hostname[count] = '\0';
    strcpy(remainders, uri_ptr);

    if (strcmp(port,"99999") == 0) {
        strcpy(port, "80"); // default port number
    }


}
/* $end parse_uri */


/*
* clienterror - returns an error message to the client
*/
/* $begin clienterror */
void clienterror(int fd, char *cause, char *errnum,
 char *shortmsg, char *longmsg)
{
    char buf[MAXLINE], body[MAXBUF];

/* Build the HTTP response body */
    sprintf(body, "<html><title>Tiny Error</title>");
    sprintf(body, "%s<body bgcolor=""ffffff"">\r\n", body);
    sprintf(body, "%s%s: %s\r\n", body, errnum, shortmsg);
    sprintf(body, "%s<p>%s: %s\r\n", body, longmsg, cause);
    sprintf(body, "%s<hr><em>The Tiny Web server</em>\r\n", body);

/* Print the HTTP response */
    /* Sometimes, calling write to send bytes on a socket that has been prematurely closed will cause
     * write to return -1 with errno set to EPIPE.
    */
    sprintf(buf, "HTTP/1.0 %s %s\r\n", errnum, shortmsg);
    if (rio_writen(fd, buf, strlen(buf)) < 0) {
        if (errno != EPIPE)
            close(fd);
    }
    sprintf(buf, "Content-type: text/html\r\n");
    if (rio_writen(fd, buf, strlen(buf)) < 0) {
        if (errno != EPIPE)
            close(fd);

    }
    sprintf(buf, "Content-length: %d\r\n\r\n", (int)strlen(body));
    if (rio_writen(fd, buf, strlen(buf)) < 0) {
        if (errno != EPIPE)
            close(fd);
    }
    if (rio_writen(fd, body, strlen(body)) < 0) {
        if (errno != EPIPE)
            close(fd);
    }
}
/* $end clienterror */