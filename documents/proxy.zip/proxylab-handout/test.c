#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int main(void) {
	char uri[200] = "http://localhost:8080/index.html";
	char hostname[200], port[200], remainders[200];
	parse_uri(uri, hostname, port, remainders);
	return 0;
}

void parse_uri(char *uri, char *hostname, char *port, char *remainders) 
{
    
    strcpy(port, "99999");
    char *uri_ptr = uri;

    if (strncasecmp(uri,"http://", 7) == 0)
        uri_ptr = uri_ptr + 7;

    int count = 0;
    while (1) {
        if (*uri_ptr == '\0' || *uri_ptr == '/') break;
        if (*uri_ptr == ':') { // extract port number
            char *port_begin = uri_ptr + 1;
            char *port_end = port_begin;
            while (*port_end != '\0' && *port_end != '/')
                port_end++;
            int port_len = port_end - port_begin;
            strncpy(port, port_begin, port_len);
            *(port + port_len) = '\0';
            uri_ptr = port_end;
            continue;
        }
        hostname[count++] = *uri_ptr;
        uri_ptr += 1;   
    }
    strcpy(remainders, uri_ptr);

    if (strcmp(port,"99999") == 0) {
        strcpy(port, "80"); // default port number
    }
    
    
}