package nodeUtil

import (
	"encoding/hex"
	"errors"
	"fmt"
	"strconv"
	"strings"
)

func Checksum(b []byte) uint16 {
	bytes := make([]byte, 20)
	copy(bytes[:20], b[:20])
	bytes[10] = 0
	bytes[11] = 0
	// Compute checksum
	var csum uint32
	for i := 0; i < len(bytes); i += 2 {
		csum += uint32(bytes[i]) << 8
		csum += uint32(bytes[i+1])
	}
	return ^uint16((csum >> 16) + csum)
}

func HexDump(b []byte) {
	for i := 0; i < len(b)/2; i++ {
		fmt.Printf("%s ", hex.EncodeToString(b[2*i:2*i+2]))
	}
}

func IpAddrIntToString(ipInt uint32) string {
	n1 := uint8((ipInt & (((1 << 8) - 1) << 24)) >> 24)
	n2 := uint8((ipInt & (((1 << 8) - 1) << 16)) >> 16)
	n3 := uint8((ipInt & (((1 << 8) - 1) << 8)) >> 8)
	n4 := uint8(ipInt & ((1 << 8) - 1))
	return fmt.Sprintf("%d.%d.%d.%d", n1, n2, n3, n4)
}

func IpAddrStringToInt(ipString string) (uint32, error) {
	numsStr := strings.Split(ipString, ".")
	var ipInt uint32 = 0
	if len(numsStr) != 4 {
		return 0, errors.New("invalid ipstring")
	}

	for i := 0; i < 4; i++ {
		num, err := strconv.Atoi(numsStr[i])
		if err != nil {
			return 0, errors.New("invalid ipstring")
		}
		ipInt |= uint32(num) << uint(24-i*8)
	}

	return ipInt, nil
}

func IpAddrPortSplit(ipAddrStr string) (string, uint16, error) {
	words := strings.Split(ipAddrStr, ":")
	if len(words) != 2 {
		return "", 0, errors.New("invalid ipAddrStr, expected form like 182.12.3.2:8583")
	}
	addr := words[0]
	port, err := strconv.Atoi(words[1])
	if err != nil || port > 65535 || port < 0 {
		return "", 0, errors.New("invalid ipAddrStr, expected form like 182.12.3.2:8583")
	}
	return addr, uint16(port), nil
}
