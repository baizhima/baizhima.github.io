/* Project 2: IP over UDP
 * Author: Shan Lu(slu5)
 *
 */

//  send 192.168.0.4 0 Hello, world!

package main

import (
	"bufio"
	"bytes"
	"encoding/binary"
	"errors"
	"fmt"
	"net"
	"nodeUtil"
	"os"
	"strconv"
	"strings"
	"sync"
	"time"
)

const MAX_IP_BUFSIZE int = 65536
const MAX_ROUTE_LIFE uint8 = 13
const REGISTERNO_PRINT_SERVICE uint8 = 0
const REGISTERNO_REVERSE_STRING uint8 = 188
const REGISTERNO_NIP_HANDLER uint8 = 200
const NODE_VERBOSE bool = false // whether print info to console

type RouteInfo struct {
	destIp  string
	cost    uint8
	nextHop string
	ttl     uint8
}

type RIPEntry struct {
	cost    uint32
	address uint32
}

type InterfaceInfo struct {
	link        *LinkLayer
	active      bool
	phyAddrFrom string
	phyAddrTo   string
	virIpFrom   *net.IPAddr
	virIpTo     *net.IPAddr
	id          int
}

type AppLayer struct {
	network *NetworkLayer
}

type NetworkLayer struct {
	registerTable map[uint8](func([]byte, uint32, string))
	routings      map[uint32]*RouteInfo
	link          *LinkLayer
	app           *AppLayer
	phyAddr       *string
	lock          sync.Mutex
}

type LinkLayer struct {
	network    *NetworkLayer
	interfaces []InterfaceInfo
	conn       *net.UDPConn
}

type NodeInfo struct {
	phyAddr string //  ip:port
	app     *AppLayer
	network *NetworkLayer
	link    *LinkLayer
}

/* ----------------------------------------------------------------------------
 * ----------------------------------------------------------------------------
 * AppLayer/node methods below
 */

// service 0, print string out
func (app *AppLayer) printService(packet []byte, srcAddr uint32, fromPhyAddr string) {
	fmt.Printf("sent by %s\n", nodeUtil.IpAddrIntToString(srcAddr))
	fmt.Printf("%s\n", packet)
}

// service 188, print reversed string out
func (app *AppLayer) reversePrint(packet []byte, srcAddr uint32, fromPhyAddr string) {
	str := string(packet)
	runes := []rune(str)
	for i, j := 0, len(runes)-1; i < j; i, j = i+1, j-1 {
		runes[i], runes[j] = runes[j], runes[i]
	}
	res := string(runes)
	fmt.Printf("%s\n", res)
}

// service 200, RIP handler
func (app *AppLayer) ripHandler(packet []byte, srcAddrInt uint32, fromPhyAddr string) {
	var command, num_entries uint16
	_buf := bytes.NewBuffer(packet)

	binary.Read(_buf, binary.BigEndian, &command)
	binary.Read(_buf, binary.BigEndian, &num_entries)

	if command == 1 {
		for i := 0; i < len(app.network.link.interfaces); i++ {
			app.network.broadcastRouting2(&app.network.link.interfaces[i])
		}
		return
	}
	entries := make([]RIPEntry, num_entries)

	for i := 0; i < int(num_entries); i++ {
		binary.Read(_buf, binary.BigEndian, &entries[i].cost)
		binary.Read(_buf, binary.BigEndian, &entries[i].address)
	}
	if NODE_VERBOSE {
		fmt.Printf("  command=%d, num_entries=%d\n", command, num_entries)
		for i := 0; i < int(num_entries); i++ {
			fmt.Printf("  address:%s, cost:%d\n", nodeUtil.IpAddrIntToString(entries[i].address), entries[i].cost)
		}
	}

	// update routing table
	hasUpdate := false
	for i := 0; i < int(num_entries); i++ {
		_isself := false
		for _, itf := range app.network.link.interfaces {
			if itf.virIpFrom.String() == nodeUtil.IpAddrIntToString(entries[i].address) {
				_isself = true
				break
			}
		}
		if _isself {
			continue
		}
		destAddrInt := entries[i].address

		var currCost uint8 = uint8(entries[i].cost) + 1
		if currCost > 16 {
			currCost = 16 // maximum allowed cost
		}
		app.network.lock.Lock()
		if route, ok := app.network.routings[destAddrInt]; ok {
			if currCost < route.cost {
				hasUpdate = true
				route.cost = currCost
				route.destIp = nodeUtil.IpAddrIntToString(destAddrInt)
				route.nextHop = fromPhyAddr
				route.ttl = MAX_ROUTE_LIFE
			} else if currCost == route.cost && route.nextHop == fromPhyAddr {
				route.ttl = MAX_ROUTE_LIFE
			} else if currCost == 16 && route.nextHop == fromPhyAddr {
				route.ttl = 1
			}
		} else {
			var rip RouteInfo
			hasUpdate = true
			rip.cost = currCost
			rip.destIp = nodeUtil.IpAddrIntToString(destAddrInt)
			rip.nextHop = fromPhyAddr
			rip.ttl = MAX_ROUTE_LIFE
			app.network.routings[destAddrInt] = &rip
		}
		app.network.lock.Unlock()
	}
	// trigger broadcast new routing information
	if hasUpdate {
		for i := 0; i < len(app.network.link.interfaces); i++ {
			app.network.broadcastRouting2(&app.network.link.interfaces[i])
		}
	}
}

/* ----------------------------------------------------------------------------
 * ----------------------------------------------------------------------------
 * NetworkLayer methods below
 */

func (network *NetworkLayer) broadcastRouting2(tointerface *InterfaceInfo) {
	if !tointerface.active {
		return
	}
	var buf_data bytes.Buffer
	var command, num_entries uint16
	command = uint16(2)

	tmpEntries := make([]RIPEntry, 0)

	for _, itf := range network.link.interfaces {
		if !itf.active {
			continue
		}
		_addrInt, err := nodeUtil.IpAddrStringToInt(itf.virIpFrom.String())
		checkError(err)
		tmpEntries = append(tmpEntries, RIPEntry{cost: 0, address: _addrInt})
	}

	for _, route := range network.routings {
		_cost := route.cost
		if route.nextHop == tointerface.phyAddrTo {
			_cost = 16
		}
		_addrInt, err := nodeUtil.IpAddrStringToInt(route.destIp)
		checkError(err)
		tmpEntries = append(tmpEntries, RIPEntry{cost: uint32(_cost), address: _addrInt})
	}

	num_entries = uint16(len(tmpEntries))
	binary.Write(&buf_data, binary.BigEndian, command)
	binary.Write(&buf_data, binary.BigEndian, num_entries)

	for i := 0; i < int(num_entries); i++ {
		binary.Write(&buf_data, binary.BigEndian, tmpEntries[i].cost)
		binary.Write(&buf_data, binary.BigEndian, tmpEntries[i].address)
	}
	dataBytes := buf_data.Bytes()

	srcAddrInt, err := nodeUtil.IpAddrStringToInt(tointerface.virIpFrom.String())
	checkError(err)
	destAddrInt, err := nodeUtil.IpAddrStringToInt(tointerface.virIpTo.String())
	checkError(err)
	ipPacket := network.encapsulateIpPacket(dataBytes, 200, srcAddrInt, destAddrInt, 0)
	network.link.sendUdpPacket(ipPacket, tointerface.phyAddrTo)
}

func (network *NetworkLayer) periodicBroadcast() {
	for {
		startTime := time.Now()
		for i := 0; i < len(network.link.interfaces); i++ {
			network.broadcastRouting2(&network.link.interfaces[i])
		}
		currTime := time.Now()
		time.Sleep(5*time.Second - currTime.Sub(startTime))
	}
}

func (network *NetworkLayer) updateTtl() {

	for {
		startTime := time.Now()
		_toDelete := make([]uint32, 0)
		network.lock.Lock()
		for key, _ := range network.routings {
			network.routings[key].ttl -= 1

			if network.routings[key].ttl == 0 {
				_toDelete = append(_toDelete, key)
			}
		}

		for _, idx := range _toDelete {
			delete(network.routings, idx)
		}
		network.lock.Unlock()
		currTime := time.Now()
		time.Sleep(1*time.Second - currTime.Sub(startTime))
	}

}

func (network *NetworkLayer) requestRoutingInfo() {
	var command, num_entries uint16 = 1, 0
	var buf_data bytes.Buffer
	binary.Write(&buf_data, binary.BigEndian, command)
	binary.Write(&buf_data, binary.BigEndian, num_entries)

	dataBytes := buf_data.Bytes()

	// send through interfaces that are still open
	for i, curr := range network.link.interfaces {
		if !curr.active {
			continue // ignore inactive interfaces
		}
		destAddr := curr.virIpTo.String()
		srcAddrInt, _, _, _ := network.findRouting2(destAddr)
		destAddrInt, err := nodeUtil.IpAddrStringToInt(destAddr)
		checkError(err)
		ipPacket := network.encapsulateIpPacket(dataBytes, 200, srcAddrInt, destAddrInt, 0)
		network.link.sendUdpPacket(ipPacket, network.link.interfaces[i].phyAddrTo)
	}

}

func (network *NetworkLayer) onRecvData(data []byte, proto uint8, destAddr string) {

	srcAddrInt, _, tointerface, islocal := network.findRouting2(destAddr)

	destAddrInt, err := nodeUtil.IpAddrStringToInt(destAddr)
	checkError(err)
	ipPacket := network.encapsulateIpPacket(data, proto, srcAddrInt, destAddrInt, 0)

	if islocal {
		if tointerface.active {
			network.onRecvIpPacket(ipPacket, *network.phyAddr)
		} else {
			fmt.Println("cannot find the host")
		}
	} else if tointerface != nil {
		network.link.sendUdpPacket(ipPacket, tointerface.phyAddrTo)
	} else {
		fmt.Println("cannot find the host")
	}

}

// switch on proto forwarding payload to different app level handler
func (network *NetworkLayer) onRecvIpPacket(ipPacket []byte, fromPhyAddr string) {

	payload, proto, srcAddrInt, destAddrInt, ttl := network.decapsulateIpPacket(ipPacket)
	_srcAddr := nodeUtil.IpAddrIntToString(srcAddrInt)
	if NODE_VERBOSE {
		fmt.Printf("[recv]ip header in hex:\n")
		nodeUtil.HexDump(ipPacket[0:20])
		fmt.Printf("ttl=%d, srcAddr=%s\n", ttl, _srcAddr)

	}

	// TODO: check whether the destAddr is within this node. If not, select the nextHop based on routing table
	if _, ok := network.routings[destAddrInt]; ok {
		destAddr := nodeUtil.IpAddrIntToString(destAddrInt)
		if ttl == 255 {
			return // drop this packet
		}
		_, _, tointerface, _ := network.findRouting2(destAddr)
		newIpPacket := network.encapsulateIpPacket(payload, proto, srcAddrInt, destAddrInt, ttl+1)

		if tointerface != nil {
			fmt.Printf("forwarding to %s\n", tointerface.virIpTo)
			network.link.sendUdpPacket(newIpPacket, tointerface.phyAddrTo)
		} else {
			fmt.Println("that's weird")
		}
	} else {

		var isLocal bool = false
		for _, curr := range network.link.interfaces {
			if curr.virIpFrom.String() == nodeUtil.IpAddrIntToString(destAddrInt) && curr.active {
				isLocal = true
				break
			}
		}
		if !isLocal {
			fmt.Printf("packet dropped. destAddrInt=%s\n", nodeUtil.IpAddrIntToString(destAddrInt))
			return
		}
		if func_ptr, ok := network.registerTable[proto]; ok {
			func_ptr(payload, srcAddrInt, fromPhyAddr)
		} else {
			network.registerTable[REGISTERNO_PRINT_SERVICE](payload, srcAddrInt, fromPhyAddr)
		}
	}

}

func (net *NetworkLayer) findRouting2(toAddr string) (vipFrom uint32,
	vipTo uint32, itf *InterfaceInfo, isLocal bool) {
	isLocal = false
	itf = nil
	vipTo, err := nodeUtil.IpAddrStringToInt(toAddr)
	checkError(err)

	var _phyTo string = ""
	for _, route := range net.routings {
		if route.destIp == toAddr {
			_phyTo = route.nextHop
			break
		}
	}

	for i, curr := range net.link.interfaces {

		if curr.phyAddrTo == _phyTo {
			itf = &net.link.interfaces[i]
			vipFrom, err = nodeUtil.IpAddrStringToInt(curr.virIpFrom.String())
			checkError(err)
			break
		}
		if curr.virIpFrom.String() == toAddr {
			isLocal = true
			itf = &net.link.interfaces[i]
			vipFrom, err = nodeUtil.IpAddrStringToInt(curr.virIpFrom.String())
			checkError(err)
			break
		}
		if curr.virIpTo.String() == toAddr {
			itf = &net.link.interfaces[i]
			vipFrom, err = nodeUtil.IpAddrStringToInt(curr.virIpFrom.String())
			checkError(err)
			break
		}
	}
	return
}

func (network *NetworkLayer) encapsulateIpPacket(payload []byte,
	proto uint8, srcAddrInt uint32, destAddrInt uint32, ttl uint8) (ipPacket []byte) {

	var version__IHL__TOS, totalLength uint16 = 0, 0 // IHL(header length)
	var identification, ipFlags__fragmentOffest uint16
	var ttl__protocol, headerChecksum uint16

	var buf_packet bytes.Buffer

	version__IHL__TOS = ((4 << 12) | (5 << 8))

	totalLength = uint16(20 + len(payload))

	ttl__protocol = uint16((uint16(ttl) << 8) | uint16(proto))

	binary.Write(&buf_packet, binary.BigEndian, version__IHL__TOS)
	binary.Write(&buf_packet, binary.BigEndian, totalLength)
	binary.Write(&buf_packet, binary.BigEndian, identification)
	binary.Write(&buf_packet, binary.BigEndian, ipFlags__fragmentOffest)
	binary.Write(&buf_packet, binary.BigEndian, ttl__protocol)
	binary.Write(&buf_packet, binary.BigEndian, headerChecksum)
	binary.Write(&buf_packet, binary.BigEndian, srcAddrInt)
	binary.Write(&buf_packet, binary.BigEndian, destAddrInt)
	binary.Write(&buf_packet, binary.BigEndian, payload)

	ipPacket = buf_packet.Bytes()

	_checksum := nodeUtil.Checksum(ipPacket[:20])
	binary.BigEndian.PutUint16(ipPacket[10:12], _checksum)

	return
}

func (network *NetworkLayer) decapsulateIpPacket(ipPacket []byte) (payload []byte, proto uint8,
	srcAddrInt uint32, destAddrInt uint32, ttl uint8) {
	var version__IHL__TOS, totalLength uint16
	var identification, ipFlags__fragmentOffest uint16
	var ttl__protocol, headerChecksum uint16

	_buf := bytes.NewBuffer(ipPacket)
	binary.Read(_buf, binary.BigEndian, &version__IHL__TOS)
	binary.Read(_buf, binary.BigEndian, &totalLength)
	binary.Read(_buf, binary.BigEndian, &identification)
	binary.Read(_buf, binary.BigEndian, &ipFlags__fragmentOffest)
	binary.Read(_buf, binary.BigEndian, &ttl__protocol)
	binary.Read(_buf, binary.BigEndian, &headerChecksum)
	binary.Read(_buf, binary.BigEndian, &srcAddrInt)
	binary.Read(_buf, binary.BigEndian, &destAddrInt)

	_checksum := nodeUtil.Checksum(ipPacket[0:20])
	if _checksum != headerChecksum {
		fmt.Printf("checksum error, packet dropped\n")
		return // drop this packet
	}

	headerLen := ((version__IHL__TOS & (15 << 8)) >> 8) * 4
	if headerLen > 20 {
		options := make([]byte, headerLen-20)
		binary.Read(_buf, binary.BigEndian, &options)
	}

	proto = uint8(ttl__protocol & 255)
	ttl = uint8(((ttl__protocol & (255 << 8)) >> 8))
	payload = ipPacket[headerLen:]

	return
}

func (network *NetworkLayer) registerHandler(proto uint8, handler func([]byte, uint32, string)) error {
	if _, ok := network.registerTable[proto]; ok {
		return errors.New("specified proto id has been registered by another method\n")
	} else {
		network.registerTable[proto] = handler
		return nil
	}

}

/* ----------------------------------------------------------------------------
 * ----------------------------------------------------------------------------
 * LinkLayer/Interface methods below
 */

func (link *LinkLayer) onRecvUdp() {

	buf := make([]byte, MAX_IP_BUFSIZE)
	for {
		numread, incomingAddr, err := link.conn.ReadFromUDP(buf)
		checkError(err)
		link.network.onRecvIpPacket(buf[0:numread], incomingAddr.String())
	}
}

func (link *LinkLayer) sendUdpPacket(ipPacket []byte, destAddr string) {
	udpAddr, err := net.ResolveUDPAddr("udp4", destAddr)
	checkError(err)
	_, err = link.conn.WriteToUDP(ipPacket, udpAddr)
	checkError(err)
}

/* ----------------------------------------------------------------------------
 * ----------------------------------------------------------------------------
 * Command Line Utilities
 */

func (link *LinkLayer) printInterfaces() {
	for _, curr := range link.interfaces {
		var activeFlag string
		if curr.active {
			activeFlag = " up "
		} else {
			activeFlag = "down"
		}
		fmt.Printf("%s; address: %s [%s]\n", curr.phyAddrTo, curr.virIpFrom.String(), activeFlag)
	}
}

func (network *NetworkLayer) printRoutes() {
	if len(network.routings) == 0 {
		fmt.Printf("[no routes]\n")
		return
	}

	for _, route := range network.routings {
		dst := route.destIp
		itf := route.nextHop
		cst := route.cost
		ttl := route.ttl
		fmt.Printf("dst: %s; interface: %s; cost: %d [ttl=%d]\n", dst, itf, cst, ttl)
	}
}

func (node *NodeInfo) setInterfaceState(interfaceNumberStr string, upDownControl bool) {
	interfaceIdx, err := strconv.ParseUint(interfaceNumberStr, 0, 64)
	if err != nil {
		fmt.Println("invalid interface:", err)
		return
	}
	if int(interfaceIdx) >= len(node.link.interfaces) {
		fmt.Printf("invalid interface number; there is %d interface\n", len(node.link.interfaces))
		return
	}

	if !upDownControl {
		var buf_data bytes.Buffer
		var command, num_entries uint16 = uint16(2), uint16(1)
		addrInt, err := nodeUtil.IpAddrStringToInt(node.link.interfaces[interfaceIdx].virIpFrom.String())
		checkError(err)
		tmpEntries := make([]RIPEntry, 0)
		tmpEntries = append(tmpEntries, RIPEntry{cost: 16, address: addrInt})

		binary.Write(&buf_data, binary.BigEndian, command)
		binary.Write(&buf_data, binary.BigEndian, num_entries)

		for i := 0; i < int(num_entries); i++ {
			binary.Write(&buf_data, binary.BigEndian, tmpEntries[i].cost)
			binary.Write(&buf_data, binary.BigEndian, tmpEntries[i].address)
		}
		dataBytes := buf_data.Bytes()

		destAddrInt, err := nodeUtil.IpAddrStringToInt(node.link.interfaces[interfaceIdx].virIpTo.String())
		checkError(err)
		ipPacket := node.network.encapsulateIpPacket(dataBytes, 200, addrInt, destAddrInt, 0)

		for _, itf := range node.network.link.interfaces {
			node.network.link.sendUdpPacket(ipPacket, itf.phyAddrTo)
		}

	}
	node.link.interfaces[interfaceIdx].active = upDownControl

}

func (node *NodeInfo) sendString(vipStr string, protoStr string, sendStr string) {
	vipAddrInt, err := nodeUtil.IpAddrStringToInt(vipStr)
	if err != nil {
		fmt.Printf("could not parse virtual IP address: %s\n", vipStr)
		return
	}
	vipAddr := nodeUtil.IpAddrIntToString(vipAddrInt)
	proto, err := strconv.Atoi(protoStr)
	if err != nil || proto > 255 || proto < 0 {
		fmt.Printf("invalid protocol number: %s\n", protoStr)
		return
	}
	node.network.onRecvData([]byte(sendStr), uint8(proto), vipAddr)
}

func (node *NodeInfo) printHelp() {
	fmt.Println("Available commands:")
	fmt.Println("  interfaces")
	fmt.Println("  routes")
	fmt.Println("  down <interface>")
	fmt.Println("  up <interface>")
	fmt.Println("  send <vip> <proto> [<string>...]")
}

func main() {
	var lnxfile string
	var broadcastAddr string = ""

	switch len(os.Args) {
	case 2:
		lnxfile = os.Args[1]
	case 4:
		if os.Args[1] != "-b" {
			invalidInput()
		}
		lnxfile = os.Args[3]
		addrInt, err := nodeUtil.IpAddrStringToInt(os.Args[2])
		broadcastAddr = nodeUtil.IpAddrIntToString(addrInt)
		if err != nil {
			fmt.Println("could not parse broadcast address")
			os.Exit(1)
		}
	default:
		invalidInput()
	}

	linkfile, err := os.Open(lnxfile)
	checkError(err)

	//broadcastAddr = ""
	fmt.Printf("lnx file %s opened, broadcastAddr=%s\n", lnxfile, broadcastAddr)

	var node NodeInfo

	node.app = &AppLayer{network: node.network} // no effect since node.network=nil
	node.network = &NetworkLayer{app: node.app, phyAddr: &node.phyAddr}
	node.link = &LinkLayer{network: node.network}
	node.network.link = node.link
	node.app.network = node.network

	node.network.registerTable = make(map[uint8](func([]byte, uint32, string)))
	node.network.routings = make(map[uint32]*RouteInfo)

	node.readLinkFile(linkfile)
	node.network.phyAddr = &node.phyAddr

	err = node.network.registerHandler(REGISTERNO_PRINT_SERVICE, node.app.printService)
	checkError(err)
	err = node.network.registerHandler(REGISTERNO_REVERSE_STRING, node.app.reversePrint)
	checkError(err)
	err = node.network.registerHandler(REGISTERNO_NIP_HANDLER, node.app.ripHandler)
	checkError(err)

	node.network.requestRoutingInfo()

	go node.link.onRecvUdp()
	go node.network.updateTtl()         // update ttl information every 1 second
	go node.network.periodicBroadcast() // send routing table info every 5s

	reader := bufio.NewReader(os.Stdin)
	for {
		node.driver(reader)
	}

}

func (node *NodeInfo) driver(reader *bufio.Reader) {

	line, err := reader.ReadString('\n')
	line = strings.TrimLeft(line, " ")

	checkError(err)

	if len(line) == 1 {
		return
	}
	line = strings.TrimSuffix(line, "\n")
	words := strings.Split(line, " ")
	switch words[0] {
	case "interfaces":
		if len(words) != 1 {
			fmt.Println("usage: interfaces")
		} else {
			node.link.printInterfaces()
		}
	case "routes":
		if len(words) != 1 {
			fmt.Println("usage: routes")
		} else {
			node.network.printRoutes()
		}
	case "down":
		if len(words) != 2 {
			fmt.Println("usage: down <interface>")
		} else {
			node.setInterfaceState(words[1], false)
		}
	case "up":
		if len(words) != 2 {
			fmt.Println("usage: down <interface>")
		} else {
			node.setInterfaceState(words[1], true)
		}
	case "send":
		if len(words) < 4 {
			fmt.Println("usage: send <vip> <proto> [<string>...]")
		} else {
			node.sendString(words[1], words[2], strings.Join(words[3:], " "))
		}
	case "help":
		node.printHelp()
	default:
		fmt.Printf("unrecognized command: '%s'; try 'help'\n", words[0])
	}

}

/* ----------------------------------------------------------------------------
 * ----------------------------------------------------------------------------
 * Misc.(read lnx file..) below**
 */

func (node *NodeInfo) readLinkFile(linkfile *os.File) {
	reader := bufio.NewReader(linkfile)
	line, err := reader.ReadString('\n')
	if err != nil {
		checkError(err)
		return
	}
	line = strings.TrimSuffix(line, "\n")
	node.phyAddr = strings.Replace(line, "localhost", "127.0.0.1", 1)

	_phyAddrFrom := strings.Replace(node.phyAddr, "localhost", "127.0.0.1", 1)
	localAddr, err := net.ResolveUDPAddr("udp", _phyAddrFrom)
	checkError(err)

	_inConn, err := net.ListenUDP("udp", localAddr)
	checkError(err)
	node.link.conn = _inConn
	_count := 0
	for {
		line, err = reader.ReadString('\n')
		if err != nil {
			break // end of read
		}
		line = strings.TrimSuffix(line, "\n")
		words := strings.Split(line, " ")
		if len(words) != 3 {
			fmt.Println("error in lnx file format, expected 3 words")
			return
		}

		_phyAddrTo := strings.Replace(words[0], "localhost", "127.0.0.1", 1)
		_vipFromAddr, _ := net.ResolveIPAddr("ip4", words[1])
		_vipToAddr, _ := net.ResolveIPAddr("ip4", words[2])

		currInterface := InterfaceInfo{
			link:        node.link,
			active:      true,
			phyAddrFrom: _phyAddrFrom,
			phyAddrTo:   _phyAddrTo,
			virIpFrom:   _vipFromAddr,
			virIpTo:     _vipToAddr,
			id:          _count}
		_count += 1
		node.link.interfaces = append(node.link.interfaces, currInterface)
	}

}

func invalidInput() {
	fmt.Printf("Usage: %s [-b <broadcast address>] <linkfile>\n", os.Args[0])
	os.Exit(1)
}

func checkError(err error) {
	if err != nil {
		fmt.Printf("fatal error: %s\n", err.Error())
		os.Exit(1)
	}
}
