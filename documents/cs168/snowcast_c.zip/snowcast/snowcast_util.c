/*
 * snowcast_util.c -- helper functions implementation
 * Author: Shan Lu(slu5)
 * Reference: Beej's Guide to Network Programming
 */
#include "snowcast_util.h"

bool
isNumber(const char *str)
{
	while (*str)
	{
		if (!isdigit(*str) && *str != '-')
		{
			return false;
		}
		str++;
	}
	return true;
}


int
strtoport(const char *str)
{
	int port = 0;
	while (*str)
	{
		if (!isdigit(*str)) return -1;
		port = port * 10 + (int)(*str - '0');
		str++;
	}
	return port;
}

void
deleteNewlineChar(char *str)
{
	
	while (*str)
	{
		if (*str == '\n')
		{
			*str = '\0';
			break;
		}
		str++;
	}
}

void *
get_in_addr(struct sockaddr *sa)
{
	if (sa->sa_family == AF_INET)
	{
		return &(((struct sockaddr_in *)sa)->sin_addr);
	}

	return &(((struct sockaddr_in6 *)sa)->sin6_addr);	
}