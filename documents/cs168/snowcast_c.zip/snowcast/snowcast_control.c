/*
 * snowcast_control.c -- a stream "client"
 * Author: Shan Lu(slu5)
 * Reference: Beej's Guide to Network Programming
 */

#include "snowcast_util.h"


#define INPUT_MAXLEN 500


typedef struct {
	bool AnnounceReceived;
	bool WelcomeReceived;
	bool InvalidCommandReceived;
	bool HelloSent;
	bool SetStationSent;
} StatusFlag;

bool
validArguments(int argc, char *argv[], char *servername, int *serverport, int *udpport)
{
	if (argc != 4) return false;
	struct hostent *he;
	if ((he = gethostbyname(argv[1])) == NULL) // get the host info
	{ 
 		fprintf(stderr, "gethostbyname error\n");
 		return false;
 	}
 	struct in_addr **addr_list = (struct in_addr **)he->h_addr_list;

 	strcpy(servername, inet_ntoa(*addr_list[0]));
 	
 	*serverport = strtoport(argv[2]);
 	*udpport = strtoport(argv[3]);
 	if (*serverport == -1 || *udpport == -1)
 	{
 		return false; // invalid port number (e.g 123a)
 	}
 	if (*serverport < 0 || *serverport > 65535)
 	{
 		fprintf(stderr, "serverport must be in [0, 65535]\n");
 		exit(1);
 	}
 	if (*udpport < 0 || *udpport > 65535)
 	{
 		fprintf(stderr, "udpport must be in [0, 65535]\n");
 		exit(1);
 	}
 	return true;
}

int
sendHello(int sockfd, int udp_port, StatusFlag *clientStatus)
{
	if (clientStatus->WelcomeReceived)
	{
		fprintf(stderr, "The server sends a Welcome before the client has sen a Hello\n");
		close(sockfd);
		exit(1);
	}

	// Hello command
	uint8_t commandType = htons(0);
	uint16_t udpPort = htons(udp_port);

	if (send(sockfd, &commandType, sizeof(uint8_t), 0) == -1)
	{
		perror("send commandType");
		return -1;
	}
	if (send(sockfd, &udpPort, sizeof(uint16_t), 0) == -1)
	{
		perror("send udpPort");
		return -1;
	}
	
	clientStatus->HelloSent = true;
	return 0;
}

int
sendSetStation(int sockfd, int stationNo, StatusFlag *clientStatus)
{
	if (clientStatus->AnnounceReceived && !clientStatus->SetStationSent)
	{
		fprintf(stderr, "The server sends an Announce before the client has sent a SetStation\n");
		close(sockfd);
		exit(1);
	}

	// SetStation command
	uint8_t commandType = 1;
	uint16_t stationNumber = htons(stationNo);

	if (send(sockfd, &commandType, sizeof(uint8_t), 0) == -1)
	{
		perror("send commandType");
		return -1;
	}
	if (send(sockfd, &stationNumber, sizeof(uint16_t), 0) == -1)
	{
		perror("send stationNumber");
		return -1;
	}
	
	return 0;
}


int
getWelcome(int sockfd, StatusFlag *clientStatus)
{
	if (clientStatus->WelcomeReceived)
	{
		fprintf(stderr, "The server sends more than one Welcome\n");
		close(sockfd);
		exit(1);
	}
	clientStatus->WelcomeReceived = true;

	uint16_t numStations;
	if (recv(sockfd, &numStations, sizeof(uint16_t), 0) == -1)
	{
		perror("get numStations");
		return -1;
	}
	numStations = ntohs(numStations);
	printf("> The server has %d station.\n", numStations);
	return numStations;
}

int
getAnnounce(int sockfd, StatusFlag *clientStatus)
{
	if (clientStatus->SetStationSent)
	{
		fprintf(stderr, "The server sends an Announce before the client has sned a SetStation\n");
		close(sockfd);
		exit(1);
	}

	clientStatus->AnnounceReceived = true;

	uint8_t songnameSize;
	if (recv(sockfd, &songnameSize, sizeof(uint8_t), 0) == -1)
	{
		perror("get songnameSize");
		return -1;
	}
	char songname[songnameSize+1];
	if (recv(sockfd, &songname, sizeof(char) * songnameSize, 0) == -1)
	{
		perror("get songname");
		return -1;
	}
	songname[songnameSize] = '\0';
	printf("received ANNOUNCE with songname = \"%s\"\n", songname);
	return 0;
}

int
getInvalidCommand(int sockfd)
{	
	uint8_t replyStringSize;
	if (recv(sockfd, &replyStringSize, sizeof(uint8_t), 0) == -1)
	{
		perror("get replyStringSize");
		return -1;
	}
	char replyString[replyStringSize];
	if (recv(sockfd, &replyString, sizeof(char) * replyStringSize, 0) == -1)
	{
		perror("get replyString");
		return -1;
	}
	printf("> invalid command: \"%s\"\n", replyString);
	close(sockfd);
	exit(1);

	return 0;
	
}

int
getReplies(int sockfd, StatusFlag * clientStatus)
{
	uint8_t replyType;
	if (recv(sockfd, &replyType, sizeof(uint8_t), 0) == -1)
	{
		perror("get replyType");
		return -1;
	}
	
	int ret;
	switch(replyType)
	{
		case 0: ret = getWelcome(sockfd, clientStatus); break;
		case 1: ret = getAnnounce(sockfd, clientStatus); break;
		case 2: ret = getInvalidCommand(sockfd); break;
		default: fprintf(stderr, "unknown replyType:%d\n", replyType); close(sockfd); exit(1);
	}
	
	return ret;
}

int
connectServer(const char *servername, int serverport)
{
	int sockfd, rv;
	struct addrinfo hints, *servinfo, *p;
	memset(&hints, 0, sizeof hints);
	hints.ai_family = AF_UNSPEC;
	hints.ai_socktype = SOCK_STREAM;
	char serverportStr[6];
	sprintf(serverportStr, "%d", serverport);
	if ((rv = getaddrinfo(servername, serverportStr, &hints, &servinfo)) != 0)
	{
		fprintf(stderr, "Could not connect to server: dial tcp %s:%d: connection refused\n",
			servername, serverport);
		exit(1);
	}

	// loop through all the results and conenct to the first
	for (p = servinfo; p != NULL; p = p->ai_next)
	{
		if ((sockfd = socket(p->ai_family, p->ai_socktype, p->ai_protocol)) == -1)
		{
			perror("client: socket");
			continue;
		}

		if (connect(sockfd, p->ai_addr, p->ai_addrlen) == -1)
		{
			close(sockfd);
			perror("client: connect");
			continue;
		}
		break;
	}

	if (p == NULL)
	{
		fprintf(stderr, "client: failed to connect\n");
		return -1;
	}

	return sockfd;
}

int
main(int argc, char *argv[])
{
	char servername[INET6_ADDRSTRLEN];
	int serverport, udpport;
	
	fd_set master;	// master file descriptor list
 	fd_set read_fds; 	// temp file descriptor list for select()
 	int fdmax = 0;

	StatusFlag clientStatus;
 	memset(&clientStatus, 0, sizeof(clientStatus));

	if (!validArguments(argc, argv, servername, &serverport, &udpport))
	{
		fprintf(stderr, "Usage: %s <servername> <serverport> <udpport>\n", argv[0]);
		exit(1);
	}
	
	int sockfd = connectServer(servername, serverport);
	sendHello(sockfd, udpport, &clientStatus);
	int stationCount = getReplies(sockfd, &clientStatus);

	FD_ZERO(&master);
 	FD_ZERO(&read_fds);

 	FD_SET(STDIN_FILENO, &master);
 	FD_SET(sockfd, &master);
 	fdmax = sockfd;


	while (true)
	{		
		printf("> ");
		read_fds = master;
 		select(fdmax+1, &read_fds, NULL, NULL, NULL);

 		if (FD_ISSET(STDIN_FILENO, &read_fds))
 		{
 			
 			char buf[INPUT_MAXLEN];
 			fgets(buf, INPUT_MAXLEN, stdin);
 			if (*buf == '\n') continue;
 			if (*buf == 'q')
 			{
 				printf("closing connection\n");
 				break;
 			}
 			deleteNewlineChar(buf);

 			int stationNo = strtoport(buf);

 			if (stationNo < 0 || stationNo > stationCount - 1)
 			{
 				printf("> command-line error: expected number in [0, %d] or \"q\"\n", stationCount-1);
 				continue;
 			}

 			clientStatus.AnnounceReceived = false;
 			clientStatus.SetStationSent = false;

 			sendSetStation(sockfd, stationNo, &clientStatus);
 			getReplies(sockfd, &clientStatus);
 		}

 		if (FD_ISSET(sockfd, &read_fds))
 		{
 			getReplies(sockfd, &clientStatus);
 		}

		
	}
	close(sockfd);
	return 0;
}