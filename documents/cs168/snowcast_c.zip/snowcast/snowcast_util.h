/*
 * snowcast_util.h -- helper functions prototypes
 * Author: Shan Lu(slu5)
 * Reference: Beej's Guide to Network Programming
 */
#ifndef SNOWCAST_UTIL_H_DEFINED
#define SNOWCAST_UTIL_H_DEFINED

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <assert.h>
#include <unistd.h>
#include <ctype.h>
#include <inttypes.h>
#include <errno.h>
#include <string.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <arpa/inet.h>



bool
isNumber(const char *str);

int
strtoport(const char *str);

void
deleteNewlineChar(char *str);

void *
get_in_addr(struct sockaddr *sa);


#endif

