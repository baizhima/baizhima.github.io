/*
 * snowcast_listener.c -- a datagram "client"
 * Author: Shan Lu(slu5)
 * Reference: Beej's Guide to Network Programming
 */

#include "snowcast_util.h"

#define MAXBUFLEN 2000



void
parseArgument(int argc, char *argv[], int *port)
{
	if (argc != 2 || !isNumber(argv[1])) 
	{
		fprintf(stderr, "Usage: %s <udpport>\n", argv[0]);
 		exit(1);
	}
	*port = strtoport(argv[1]);
	
 	if (*port < 0 || *port > 65535)
 	{
 		fprintf(stderr, "udpport must be in [0, 65535]\n");
 		exit(1);
 	}

}

 int
 main(int argc, char *argv[])
 {
 	int sockfd, udpport;
 	struct addrinfo hints, *servinfo, *p;
 	int rv, numbytes;
 	struct sockaddr_storage their_addr;
 	char buf[MAXBUFLEN];
 	socklen_t addr_len;

 	memset(&hints, 0, sizeof hints);
 	hints.ai_family = AF_UNSPEC;
 	hints.ai_socktype = SOCK_DGRAM;
 	hints.ai_flags = AI_PASSIVE;

 	parseArgument(argc, argv, &udpport);

 	char udpportStr[6];
	sprintf(udpportStr, "%d", udpport);

 	if ((rv = getaddrinfo(NULL, udpportStr, &hints, &servinfo)) != 0)
 	{
 		fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(rv));
 		return 1;
 	}

 	// loop through all results and bind to the first we can
 	for (p = servinfo; p != NULL; p = p->ai_next)
 	{
 		if ((sockfd = socket(p->ai_family, p->ai_socktype, p->ai_protocol)) == -1)
 		{
 			perror("listener: socket");
 			continue;
 		}

 		if (bind(sockfd, p->ai_addr, p->ai_addrlen) == -1)
 		{
 			close(sockfd);
 			perror("listener: bind");
 			continue;
 		}

 		break;
 	}

 	if (p == NULL)
 	{
 		fprintf(stderr, "listener: failed to bind socket\n");
 		return 2;
 	}

 	freeaddrinfo(servinfo);

 	addr_len = sizeof their_addr;
 	printf("listening on sockfd: %d\n", sockfd);
 	while ((numbytes = recvfrom(sockfd, buf, MAXBUFLEN-1, 0,
 		(struct sockaddr *)&their_addr, &addr_len)) > 0)
 	{		
 		write(STDOUT_FILENO, buf, numbytes);
				
 	}	
 	
 	close(sockfd);
 	
 	return 0;
 }