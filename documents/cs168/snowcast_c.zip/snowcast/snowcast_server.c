/*
 * snowcast_server.c -- a stream "server"
 * Author: Shan Lu(slu5)
 * Reference: Beej's Guide to Network Programming
 */

#include "snowcast_util.h"
#include <pthread.h>
#include <sys/time.h>
#include <time.h>

#define UDP_PACKET_SIZE 1024

typedef struct ClientInfo ClientInfo;

struct ClientInfo{
	ClientInfo *next;
	char hostname[INET6_ADDRSTRLEN];
	
	int udpport;
	struct sockaddr dest_addr;
	socklen_t dest_addrlen;
	int control_fd;
	int listener_fd;
};

typedef struct 
{
	int stationID;
	FILE *fp; // mp3 file that station is playing
	char *filename;
	int numClients;
	ClientInfo *head; // linklist
	pthread_mutex_t lock;
} StationInfo;

typedef struct 
{
	int tcpport;	// listening port no
	int listen_fd;  // socket file descriptor
	int numStations;
	fd_set master;
	int fdmax;
	StationInfo *stations;
	
	int fdCapacity;
	int fdCount;
	int *clients_control_fd;
	pthread_mutex_t fdlock;
} ServerInfo;


typedef struct 
{
	ServerInfo *server;
	int control_fd;
	char remoteIP[INET6_ADDRSTRLEN];
} ArgClientInit;

void
sendInvalidCommand(int sockfd, const char *contentStr);

void
initServer(int argc, char *argv[], ServerInfo *server)
{
	if (argc < 3 || !isNumber(argv[1])) 
	{
		fprintf(stderr, "Usage: %s <tcpport> <file>...\n", argv[0]);
 		exit(1);
	}
	server->tcpport = strtoport(argv[1]);
	if (server->tcpport < 0 || server->tcpport > 65535)
 	{
 		fprintf(stderr, "tcpport must be in [0, 65535]\n");
 		exit(1);
 	}
 	server->listen_fd = -1;
 	server->numStations = argc - 2;
 	FD_ZERO(&server->master);
 	server->fdmax = 0;
 	server->stations = (StationInfo *)malloc(sizeof(StationInfo) * server->numStations);
 	for (int i = 0; i < server->numStations; i++)
 	{
 		server->stations[i].stationID = i;
 		server->stations[i].fp = fopen(argv[2+i], "rb");
 		if (!server->stations[i].fp)
 		{
 			fprintf(stderr, "error opening file %s: no such file or directory\n", argv[2+i]);
 			exit(1);
 		}
 		server->stations[i].filename = (char *)malloc(sizeof(char) * (strlen(argv[2+i]) + 1));
 		strcpy(server->stations[i].filename, argv[2+i]);
 		server->stations[i].numClients = 0;
 		server->stations[i].head = NULL;
 		pthread_mutex_init(&server->stations[i].lock, NULL);
 	}	
 	server->fdCapacity = 1; // init value
 	server->fdCount = 0;
 	server->clients_control_fd = (int *)malloc(sizeof(int) * server->fdCapacity);
 	pthread_mutex_init(&server->fdlock, NULL);
 	 
}

// create socket, bind and listen on tcpport. Return socket file descriptor
void
getTcpSocket(ServerInfo *server)
{
	int sockfd;
	struct addrinfo hints, *servinfo, *p;
 	int rv;
 	
 	memset(&hints, 0, sizeof hints);
 	hints.ai_family = AF_UNSPEC;
 	hints.ai_socktype = SOCK_STREAM;
 	hints.ai_flags = AI_PASSIVE;
 	int yes = 1;
 	char tcpport_str[6];
 	sprintf(tcpport_str, "%d", server->tcpport);

 	if ((rv = getaddrinfo(NULL, tcpport_str, &hints, &servinfo)) != 0)
 	{
 		fprintf(stderr, "getaddrinfo error: %s\n", gai_strerror(rv));
 		exit(1);
 	}

 	// loop through all the results and bind to the first
 	for (p = servinfo; p != NULL; p = p->ai_next)
 	{
 		if ((sockfd = socket(p->ai_family, p->ai_socktype,
 								p->ai_protocol)) == -1)
 		{
 			continue;
 		}

 		if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &yes,
 							sizeof(int)) == -1)
 		{
 			close(sockfd);
 			continue;
 		}

 		if (bind(sockfd, p->ai_addr, p->ai_addrlen) == -1)
 		{
 			close(sockfd);
 			continue;
 		}
 		break;
 	}
 	freeaddrinfo(servinfo);
 	if (p == NULL)
 	{
 		fprintf(stderr, "server: failed to bind a listening port\n");
 		exit(1);
 	}

 	if (listen(sockfd, 50) == -1) {
 		fprintf(stderr, "server: failed to listen on socket %d\n", sockfd);
 		exit(1);
 	}	
 	server->listen_fd = sockfd;
}

void
printServerInfo(ServerInfo *server)
{
	for (int i = 0; i < server->numStations; i++)
	{
		printf("Station %d playing \"%s\"; listening [",i,server->stations[i].filename);
		ClientInfo *ptr = server->stations[i].head;
		while (ptr)
		{
			printf("%s:%d",ptr->hostname,ptr->udpport);
			if (ptr->next)
			{
				printf(" ");
			}
			ptr = ptr->next;
		}
		printf("]\n");
	}
}

void
disposeServer(ServerInfo *server)
{
	close(server->listen_fd);
	for (int i = 0; i < server->numStations; i++)
	{
		StationInfo *curr = &server->stations[i];
		fclose(curr->fp);
		free(curr->filename);
		while (curr->head)
		{
			ClientInfo *ptr = curr->head;
			curr->head = curr->head->next;
			free(ptr);
		}	
	}
	free(server->stations);
}


bool
getHello(int sockfd, int *udp_port)
{
	uint8_t commandType;
	uint16_t udpPort;
	
	if (recv(sockfd, &commandType, sizeof(uint8_t), 0) == -1)
	{
		sendInvalidCommand(sockfd, "failed to receive commandType");
		return false;
	}
	if (commandType != 0)
	{
		sendInvalidCommand(sockfd, "invalid commandType; expected HELLO but failed");
        return false;
	}
	if (recv(sockfd, &udpPort, sizeof(uint16_t), 0) == -1)
	{
		sendInvalidCommand(sockfd, "failed to receive udpport");
		return false;
	}
	*udp_port = ntohs(udpPort);
    if (*udp_port < 0 || *udp_port > 65536)
    {
        sendInvalidCommand(sockfd, "invalid udp_port");
        return false;
    }
	printf("session id %2d: received HELLO with udpport = %d;", sockfd, ntohs(udpPort));
	return true;
}

bool
getSetStation(int sockfd, int *stationNo, int numStations)
{
	uint8_t commandType;
	uint16_t stationNumber;
	if (recv(sockfd, &commandType, sizeof(uint8_t), 0) == -1)
	{
		sendInvalidCommand(sockfd, "failed to receive commandType");
		return false;
	}
	if (commandType != 1)
	{
		sendInvalidCommand(sockfd, "invalid commandType; expected SetStation but failed");
        return false;
	}
	if (recv(sockfd, &stationNumber, sizeof(uint16_t), 0) == -1)
	{
		sendInvalidCommand(sockfd, "failed to receive stationNumber");
		return false;
	}
	*stationNo = ntohs(stationNumber);
	if (*stationNo < 0 || *stationNo >= numStations) // 'q' is pressed
	{
		sendInvalidCommand(sockfd, "Station specified does not exist");
		return false;
	}
	printf("session id %2d: received SET_STATION with stationNumber = %d\n", sockfd, (int)ntohs(stationNumber));
	return true;
}

bool
sendWelcome(int sockfd, int nrStations)
{
	uint8_t replyType = 0;
	uint16_t numStations = htons(nrStations);
	if (send(sockfd, &replyType, sizeof(uint8_t), 0) == -1)
	{
		perror("sendWelcome replyType error\n");
		return false;
	}
	if (send(sockfd, &numStations, sizeof(uint16_t), 0) == -1)
	{
		perror("sendWelcome numStations error\n");
		return false;
	}
	printf(" sending WELCOME; expecting SET_STATION\n");
	return true;	
}

bool
sendAnnounce(int sockfd, const char *songName)
{
	uint8_t replyType = 1;
	uint8_t songnameSize = strlen(songName);
	char songname[songnameSize+1];
	strcpy(songname, songName);

	if (send(sockfd, &replyType, sizeof(uint8_t), 0) == -1)
	{
		perror("sendAnnounce replyType error\n");
		return false;
	}
	if (send(sockfd, &songnameSize, sizeof(uint8_t), 0) == -1)
	{
		perror("sendAnnounce songnameSize error\n");
		return false;
	}
	if (send(sockfd, &songname, sizeof(char) * songnameSize, 0) == -1)
	{
		perror("sendAnnounce songname error\n");
		return false;
	}
	return true;
}

void
sendInvalidCommand(int sockfd, const char *contentStr)
{
    uint8_t replyType = 2;
    uint8_t replyStringSize = strlen(contentStr);
    char replyString[replyStringSize+1];
    strcpy(replyString, contentStr);

    if (send(sockfd, &replyType, sizeof(uint8_t), 0) == -1)
    {
        perror("sendInvalidCommand replyType send error\n");
        return;
    }
    if (send(sockfd, &replyStringSize, sizeof(uint8_t), 0) == -1)
    {
        perror("sendInvalidCommand replyStringSize send error\n");
        return;
    }
    if (send(sockfd, &replyString, sizeof(char) * replyStringSize, 0) == -1)
    {
        perror("sendInvalidCommand replyString send error\n");
        return;
    }
    
}

bool
initListenerSocket (ClientInfo *client, const char *remoteIP, int udpport)
{
	int sockfd;
	struct addrinfo hints, *servinfo, *p;
	int rv;

	memset(&hints, 0, sizeof hints);
	hints.ai_family = AF_UNSPEC;
	hints.ai_socktype = SOCK_DGRAM;
	char port_str[6];
	sprintf(port_str, "%d", udpport);

	if ((rv = getaddrinfo(remoteIP, port_str, &hints, &servinfo)) != 0)
	{
		fprintf(stderr, "getListenerSocket getaddrinfo: %s\n", gai_strerror(rv));
 		return false;
	}

	for (p = servinfo; p != NULL; p = p->ai_next)
	{
		if ((sockfd = socket(p->ai_family, p->ai_socktype,p->ai_protocol)) == -1)
		{
			perror("getListenerSocket: socket");
			continue;
		}
		break;
	}
	
	if (p == NULL)
	{
		fprintf(stderr, "getListenerSocket: failed to create socket\n");
		return false;
	}
	client->listener_fd = sockfd;
	memcpy(&client->dest_addr, p->ai_addr, sizeof(struct sockaddr));
	client->dest_addrlen = p->ai_addrlen;
	freeaddrinfo(servinfo);
	return true;	
}

void
updateFdset(ServerInfo *server, int control_fd)
{
	int i;
	printf("session id %2d: client closed connection\n", control_fd);
	
	close(control_fd);
	pthread_mutex_lock(&server->fdlock);
	FD_CLR(control_fd, &server->master);

	for (i = 0; i < server->fdCount; i++)
	{
		if (server->clients_control_fd[i] == control_fd)
			break;
	}
	for (int j = i; j < server->fdCount-1; j++)
	{
		server->clients_control_fd[j] = server->clients_control_fd[j+1];
	}
	server->fdCount -= 1;
	
	pthread_mutex_unlock(&server->fdlock);
}


void *
initClient(void *argument)
{

	ArgClientInit *args = (ArgClientInit *)argument;
	ServerInfo *server = args->server;
	int control_fd = args->control_fd;
	const char *remoteIP = args->remoteIP;

	int udpport, stationNo;

	if (!getHello(control_fd, &udpport)
		|| !sendWelcome(control_fd, server->numStations) 
		|| !getSetStation(control_fd, &stationNo, server->numStations))
	{
		printf("session id %2d: client closed connection[no handshake]\n", control_fd);
		FD_CLR(control_fd, &server->master);
		if (server->fdmax == control_fd)
		{
			server->fdmax -= 1;
		}
		close(control_fd);
		free(args);
		return 0;
	}
	
	ClientInfo *client = (ClientInfo *)malloc(sizeof(ClientInfo));
	client->udpport = udpport;
	client->control_fd = control_fd;
	if (!initListenerSocket(client, remoteIP, udpport))
	{
		close(control_fd);
		free(client);
		return 0;
	}
	strcpy(client->hostname,remoteIP);

    pthread_mutex_lock(&server->stations[stationNo].lock);
	client->next = server->stations[stationNo].head;
	server->stations[stationNo].head = client;
	server->stations[stationNo].numClients += 1;
	
	if (!sendAnnounce(client->control_fd, server->stations[stationNo].filename))
	{
		
		free(client);
		return 0;
	}
	pthread_mutex_unlock(&server->stations[stationNo].lock);
	pthread_mutex_lock(&server->fdlock);
	server->clients_control_fd[server->fdCount++] = control_fd;

    if (server->fdCount == server->fdCapacity)	// resize clients_control_fd array once capacity is met
    {
        server->fdCapacity *= 2;
        server->clients_control_fd = (int *)realloc(server->clients_control_fd, sizeof(int) * server->fdCapacity);
    }
    
    pthread_mutex_unlock(&server->fdlock);
    //printf("initClient reach here, fdCount = %d, control_fd=%d\n",server->fdCount, control_fd);
    free(args);
	return 0;
}

void
switchStation(ServerInfo *server, int from, int to, ClientInfo *client)
{
    if (from == to 
    	|| from >= server->numStations || from < 0 
    	|| to >= server->numStations || to < 0)	
    {
    	return;
    }
    StationInfo *src = &server->stations[from], *dest = &server->stations[to];
    
    
    ClientInfo *ptr = src->head, *prev = NULL;
    while (ptr != client)
    {
        prev = ptr;
        ptr = ptr->next;
    }
    if (!ptr)
    {
    	return;
    }
    if (prev)
    {
        prev->next = client->next;      
    }
    else
    {
        src->head = client->next;
    }
    src->numClients -= 1;
    client->next = dest->head;
    dest->head = client;
    dest->numClients += 1;  
}

void
removeClient(ServerInfo *server, int control_fd)
{
	int i;
	updateFdset(server, control_fd);

	for (i = 0; i < server->numStations; i++)
    {
    	pthread_mutex_lock(&server->stations[i].lock);
    }
    ClientInfo *ptr, *prev;
    for (i = 0; i < server->numStations; i++)
    {
        ptr = server->stations[i].head;
        prev = NULL;
        bool clientFound = false;
        while (ptr)
        {
            if (ptr->control_fd == control_fd)
            {   
                clientFound = true;
                break;
            }
            prev = ptr;
            ptr = ptr->next;
        }
        if (clientFound)
        {
            break;
        }
    }
    if (!ptr)
    {
    	return;
    }
    if (prev)
    {
    	prev->next = ptr->next;
    }
    else
    {
    	server->stations[i].head = ptr->next;
    }
    free(ptr);
    server->stations[i].numClients -= 1;
 
	for (i = 0; i < server->numStations; i++)
    {
    	pthread_mutex_unlock(&server->stations[i].lock);
    }	
}

void
clientInteract(ServerInfo *server, int control_fd)
{
	uint8_t commandType;
	uint16_t stationNo;
	
    int srcStation, destStation;

    if (recv(control_fd, &commandType, sizeof(uint8_t), 0) == -1)
	{
		removeClient(server, control_fd);
		return;
	}
	if (commandType != 1) 
	{
		sendInvalidCommand(control_fd, "clientInteract: invalid commandType");
		removeClient(server, control_fd); 
		
		return;	
	}

    if (recv(control_fd, &stationNo, sizeof(uint16_t), 0) == -1)
	{
		perror("receiving stationNo error\n");
		removeClient(server, control_fd);
		return;
	}
	destStation = ntohs(stationNo);

    for (int i = 0; i < server->numStations; i++)
    {
    	pthread_mutex_lock(&server->stations[i].lock);
    }
    ClientInfo *ptr = NULL;
    for (int i = 0; i < server->numStations; i++)
    {
        ptr = server->stations[i].head;
        bool clientFound = false;
        while (ptr)
        {
            if (ptr->control_fd == control_fd)
            {   
                srcStation = i;
                clientFound = true;
                break;
            }
            ptr = ptr->next;
        }
        if (clientFound)
        {
            break;
        }
    }
    if (srcStation != destStation)
    {
        switchStation(server, srcStation, destStation, ptr);     
    }
    
    sendAnnounce(ptr->control_fd, server->stations[destStation].filename);
    for (int i = 0; i < server->numStations; i++)
    {
    	pthread_mutex_unlock(&server->stations[i].lock);
    }
}

void *
playStation(void *arg)
{
	StationInfo *station = (StationInfo *) arg;

	int numbytes;
	char data[UDP_PACKET_SIZE];
	struct timeval stop, start;

	while (true)
	{
        gettimeofday(&start, NULL);
        pthread_mutex_lock(&station->lock);
        ClientInfo *client = station->head;
        bool announce = false;
        if(!fread(data, 1, UDP_PACKET_SIZE, station->fp))
        {
        	rewind(station->fp);
        	fread(data, 1, UDP_PACKET_SIZE, station->fp);
        	announce = true;
        }
		
        while (client)
        {
        	if (announce)
        	{
        		sendAnnounce(client->control_fd, station->filename);
        	}
		
        	if ((numbytes = sendto(client->listener_fd, data, UDP_PACKET_SIZE, 0, &client->dest_addr, client->dest_addrlen)) == -1)
        	{
        		perror("sendto error");
        		return false;
        	}
        	client = client->next;
        }
        pthread_mutex_unlock(&station->lock);
        gettimeofday(&stop, NULL);
		usleep(1e6/16-(stop.tv_usec - start.tv_usec) - 1.5e3);      
	}
}

int
main(int argc, char *argv[])
{
    ServerInfo server;
	pthread_t pid[argc-2];
	
 	fd_set read_fds; 	// temp file descriptor list for select()
 	struct sockaddr_storage their_addr; // connector's address information
 	socklen_t sin_size = sizeof their_addr;
 	char remoteIP[INET6_ADDRSTRLEN];

	initServer(argc, argv, &server);
	getTcpSocket(&server); // server.listen_fd ready
 	FD_ZERO(&read_fds);
 	FD_SET(STDIN_FILENO, &server.master);
 	FD_SET(server.listen_fd, &server.master);
 	server.fdmax = server.listen_fd;

	for (int i = 0; i < server.numStations; i++)
	{ 	
    	if (pthread_create(&pid[i], 0, playStation, (void *)&server.stations[i]) != 0)
    	{
    		fprintf(stderr,"pthread_create error\n");
    		exit(1);
    	}
	}

	while (true)
	{
		FD_ZERO(&read_fds);
		read_fds = server.master;
		
 		select(server.fdmax+1, &read_fds, NULL, NULL, 0);
 		

 		if (FD_ISSET(STDIN_FILENO, &read_fds))
 		{
 			// server REPL input p or q
 			char line[300];
 			fgets(line, 300, stdin);
 			deleteNewlineChar(line);
 			if (strlen(line) > 1 || (*line != 'p' && *line != 'q'))
 			{
 				printf("Expected \"p\" or \"q\"\n");
 				continue;
 			}
 			if (*line == 'p')
 			{
 				printServerInfo(&server);
 			}
 			if (*line == 'q')
 			{
 				break;
 			}
 		}

 		if (FD_ISSET(server.listen_fd, &read_fds))
 		{
 			int new_fd;
 			if ((new_fd = accept(server.listen_fd, (struct sockaddr *)&their_addr, &sin_size)) == -1)
 			{
 				perror("accept failed\n");
 				continue;
 			}
 			printf("selectserver: new connection from %s on new_fd: %d\n", inet_ntop(their_addr.ss_family,
 					  get_in_addr((struct sockaddr*)&their_addr), remoteIP, INET6_ADDRSTRLEN), new_fd);
            
            ArgClientInit *funcarg = (ArgClientInit *)malloc(sizeof(ArgClientInit));
            funcarg->server = &server;
            funcarg->control_fd = new_fd;

            strcpy(funcarg->remoteIP, remoteIP);
            
            pthread_t pinitid;
            FD_SET(new_fd, &server.master);
            server.fdmax = new_fd > server.fdmax ? new_fd : server.fdmax;
            pthread_create(&pinitid, 0, initClient, (void *)funcarg);
       		
 		}
 		
        for (int i = 0; i < server.fdCount; i++)
        {          
            if (FD_ISSET(server.clients_control_fd[i], &read_fds))
            {
         
                clientInteract(&server, server.clients_control_fd[i]); 

            }     
        }
       
	}
	disposeServer(&server);
	return 0;
}