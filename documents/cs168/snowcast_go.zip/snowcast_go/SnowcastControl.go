/* snowcast_control
 */

package main

import (
	"bufio"
	"encoding/binary"
	"fmt"
	"net"
	"os"
	"snowcast_util"
)

const INPUT_MAXLEN int = 500

type StatusFlag struct {
	AnnounceReceived       bool
	WelcomeReceived        bool
	InvalidCommandReceived bool
	HelloSent              bool
	SetStationSent         bool
}

func parseArgument(argv []string, udpport *int) bool {
	if len(argv) != 4 {
		return false
	}

	serverport := snowcast_util.StrToPort(argv[2])
	*udpport = snowcast_util.StrToPort(argv[3])
	if serverport == -1 || *udpport == -1 {
		return false // invalid port number (e.g 123a)
	}
	if serverport < 0 || serverport > 65535 {
		fmt.Fprintf(os.Stderr, "serverport must be in [0, 65535]\n")
		os.Exit(1)
	}
	if *udpport < 0 || *udpport > 65535 {
		fmt.Fprintf(os.Stderr, "udpport must be in [0, 65535]\n")
		os.Exit(1)
	}
	return true

}

func sendHello(conn *net.TCPConn, udpport int, clientStatus *StatusFlag) {
	if clientStatus.WelcomeReceived {
		fmt.Fprintf(os.Stderr, "The server sends a Welcome before the client has sen a Hello\n")
		os.Exit(1)
	}
	// Hello commmand
	var commandType uint8 = 0
	var udpPort uint16 = uint16(udpport)

	err := binary.Write(conn, binary.BigEndian, commandType)
	checkError(err)

	err = binary.Write(conn, binary.BigEndian, udpPort)
	checkError(err)

	clientStatus.HelloSent = true
}

func sendSetStation(conn *net.TCPConn, stationNo int, clientStatus *StatusFlag) int {
	if clientStatus.AnnounceReceived && !clientStatus.SetStationSent {
		fmt.Fprintf(os.Stderr, "The server sends an Announce before the client has sent a SetStation\n")
		os.Exit(1)
	}

	var commandType uint8 = 1
	var stationNumber uint16 = uint16(stationNo)
	err := binary.Write(conn, binary.BigEndian, commandType)
	if err != nil {
		checkError(err)
		return -1
	}

	err = binary.Write(conn, binary.BigEndian, stationNumber)
	if err != nil {
		checkError(err)
		return -1
	}

	return 0

}

func getWelcome(conn *net.TCPConn, clientStatus *StatusFlag) int {
	if clientStatus.WelcomeReceived {
		fmt.Fprintf(os.Stderr, "The server sends more than one Welcome\n")
		os.Exit(1)
	}
	clientStatus.WelcomeReceived = true
	var numStations uint16
	err := binary.Read(conn, binary.BigEndian, &numStations)
	if err != nil {
		checkError(err)
		fmt.Fprintf(os.Stderr, "get numStations")
		return -1
	}
	fmt.Fprintf(os.Stdout, "> The server has %d station.\n", numStations)
	return int(numStations)
}

func getAnnounce(conn *net.TCPConn, clientStatus *StatusFlag) int {
	if clientStatus.SetStationSent {
		fmt.Fprintf(os.Stderr, "The server sends an Announce before the client has sned a SetStation\n")
		os.Exit(1)
	}
	clientStatus.AnnounceReceived = true

	var songnameSize uint8
	err := binary.Read(conn, binary.BigEndian, &songnameSize)
	if err != nil {
		checkError(err)
		fmt.Fprintf(os.Stderr, "get songnameSize\n")
		return -1
	}

	songname := make([]byte, songnameSize)
	err = binary.Read(conn, binary.BigEndian, &songname)
	if err != nil {
		checkError(err)
		fmt.Fprintf(os.Stderr, "get songname\n")
		return -1
	}

	fmt.Fprintf(os.Stdout, "received ANNOUNCE with songname = \"%s\"\n", string(songname))
	return 0
}

func getInvalidCommand(conn *net.TCPConn) int {
	var replyStringSize uint8
	err := binary.Read(conn, binary.BigEndian, &replyStringSize)
	if err != nil {
		checkError(err)
		fmt.Fprintf(os.Stderr, "get replyStringSize")
		return -1
	}

	var replyString = make([]byte, replyStringSize)
	err = binary.Read(conn, binary.BigEndian, &replyString)
	if err != nil {
		checkError(err)
		fmt.Fprintf(os.Stderr, "get replyString")
		return -1
	}
	fmt.Println("> invalid command: \"", replyString, "\"")
	os.Exit(1)

	return 0

}

func getReplies(conn *net.TCPConn, clientStatus *StatusFlag) int {
	var replyType uint8
	ret := 0
	err := binary.Read(conn, binary.BigEndian, &replyType)
	checkError(err)

	switch replyType {
	case 0:
		ret = getWelcome(conn, clientStatus)
	case 1:
		ret = getAnnounce(conn, clientStatus)
	case 2:
		ret = getInvalidCommand(conn)
	default:
		fmt.Fprintf(os.Stderr, "unknown replyType:%d\n", replyType)
		os.Exit(1)
	}

	return ret
}

func handleServerInput(line string) {
	command := line[0]
	if command == 'q' {
		fmt.Println("control closing connection")
		os.Exit(1)
	}
	if command == 'p' {
		fmt.Println("print station information")
	}
}

func main() {

	var udpport int
	var clientStatus = StatusFlag{false, false, false, false, false}

	if !parseArgument(os.Args, &udpport) {
		fmt.Fprintf(os.Stderr, "Usage: %s <servername> <serverport> <udpport>\n", os.Args[0])
		os.Exit(1)
	}

	tcpAddr, err := net.ResolveTCPAddr("tcp4", os.Args[1]+":"+os.Args[2])
	checkError(err)

	conn, err := net.DialTCP("tcp", nil, tcpAddr)
	checkError(err)

	sendHello(conn, udpport, &clientStatus)

	stationCount := getReplies(conn, &clientStatus)

	fmt.Printf("> ")

	// client-side: sending SetStation, close connection
	go func() {
		for {
			getReplies(conn, &clientStatus)
			fmt.Printf("> ")
		}

	}()
	reader := bufio.NewReader(os.Stdin)
	for {
		line, err := reader.ReadString('\n')

		checkError(err)
		if len(line) == 1 {
			fmt.Printf("> ")
			continue // blank line
		}
		line = line[0 : len(line)-1] // strip('\n')
		if rune(line[0]) == rune('q') {
			fmt.Println("control closing connection")
			os.Exit(1)
		}
		stationNo := snowcast_util.StrToPort(line)
		if stationNo < 0 || stationNo > stationCount {
			fmt.Printf("> command-line error: expected number in [0, %d] or \"q\"n",
				stationCount-1)
			continue
		}
		clientStatus.AnnounceReceived = false
		clientStatus.SetStationSent = false

		sendSetStation(conn, stationNo, &clientStatus)

	}

}

func checkError(err error) {
	if err != nil {
		fmt.Fprintf(os.Stderr, "fatal error: %s\n", err.Error())
		os.Exit(1)
	}
}
