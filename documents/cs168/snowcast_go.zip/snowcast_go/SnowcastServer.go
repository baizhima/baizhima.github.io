/* snowcast_server
 */

package main

import (
	"bufio"
	"encoding/binary"
	"fmt"
	"net"
	"os"
	"snowcast_util"
	"strconv"
	"strings"
	"sync"
	"time"
)

type ClientInfo struct {
	next         *ClientInfo
	controlConn  *net.TCPConn
	listenerConn *net.UDPConn
	udpport      uint16
	address      string
}

type StationInfo struct {
	stationID  int
	fp         *os.File
	filename   string
	numClients int
	head       *ClientInfo
	lock       sync.Mutex
}

type ServerInfo struct {
	tcpport     int
	numStations int
	stations    []StationInfo
	listener    *net.TCPListener
	numClients  int
}

const UDP_PACKET_SIZE int = 1024

func initServer(server *ServerInfo) {
	if len(os.Args) < 3 || !snowcast_util.IsNumber(os.Args[1]) {
		fmt.Fprintf(os.Stderr, "Usage: %s <tcpport> <file>...\n", os.Args[0])
		os.Exit(1)
	}
	server.tcpport = snowcast_util.StrToPort(os.Args[1])
	if server.tcpport < 0 || server.tcpport > 65535 {
		fmt.Fprintf(os.Stderr, "tcpport must be in [0, 65535]\n")
		os.Exit(1)
	}
	server.numStations = len(os.Args) - 2
	for i := 0; i < server.numStations; i++ {
		var currStation StationInfo
		currStation.stationID = i
		fp, err := os.Open(os.Args[2+i])
		if err != nil {
			fmt.Fprintf(os.Stderr, "error opening file %s: no such file or directory\n", os.Args[2+i])
			os.Exit(1)
		}
		currStation.fp = fp
		currStation.filename = os.Args[2+i]
		server.stations = append(server.stations, currStation)
	}
	server.numClients = 0
}

func setTcpConn(server *ServerInfo) {
	service := "0.0.0.0:" + strconv.Itoa(server.tcpport)
	tcpAddr, err := net.ResolveTCPAddr("tcp", service)
	if err != nil {
		fmt.Fprintf(os.Stderr, "error resolving tcp address")
		os.Exit(1)
	}
	listener, err := net.ListenTCP("tcp", tcpAddr)
	if err != nil {
		fmt.Fprintf(os.Stderr, "error listening on port %d", server.tcpport)
		os.Exit(1)
	}
	server.listener = listener
}

func printServerInfo(server *ServerInfo) {
	for i := 0; i < server.numStations; i++ {
		fmt.Printf("Station %d playing \"%s\"; listening [", i, server.stations[i].filename)
		server.stations[i].lock.Lock()
		for ptr := server.stations[i].head; ptr != nil; ptr = ptr.next {
			fmt.Printf("%s:%d", ptr.address, ptr.udpport)
			if ptr.next != nil {
				fmt.Printf(" ")
			}
		}
		fmt.Printf("]\n")
		server.stations[i].lock.Unlock()
	}

}

func getHello(conn *net.TCPConn, udpport *uint16) bool {
	var commandType uint8
	var udpPort uint16

	err := binary.Read(conn, binary.BigEndian, &commandType)
	if err != nil {
		sendInvalidCommand(conn, "failed to receive commandType")
		return false
	}
	if commandType != 0 {
		sendInvalidCommand(conn, "invalid commandType; expected HELLO but failed")
		return false
	}

	err = binary.Read(conn, binary.BigEndian, &udpPort)
	if err != nil {
		sendInvalidCommand(conn, "failed to receive udpport")
		return false
	}
	if udpPort < 1024 {
		sendInvalidCommand(conn, "invalid udp_port "+string(udpPort))
		return false
	}

	*udpport = udpPort
	return true
}

func getSetStation(conn *net.TCPConn, stationNo *int, numStations int) bool {
	var commandType uint8
	var stationNumber uint16

	err := binary.Read(conn, binary.BigEndian, &commandType)
	if err != nil {
		sendInvalidCommand(conn, "failed to receive commandType")
		return false
	}
	if commandType != 1 {
		sendInvalidCommand(conn, "invalid commandType; expected SetStation but failed")
		return false
	}

	err = binary.Read(conn, binary.BigEndian, &stationNumber)
	if err != nil {
		sendInvalidCommand(conn, "failed to receive stationNumber")
		return false
	}

	*stationNo = int(stationNumber)
	if *stationNo < 0 || *stationNo >= numStations {
		sendInvalidCommand(conn, "Station specified does not exist")
		return false
	}

	return true
}

func sendWelcome(conn *net.TCPConn, nrStations int) bool {
	var replyType uint8 = 0
	var numStations uint16 = uint16(nrStations)
	err := binary.Write(conn, binary.BigEndian, replyType)
	if err != nil {
		fmt.Fprintf(os.Stdout, "error writing replyType")
		return false
	}

	err = binary.Write(conn, binary.BigEndian, numStations)
	if err != nil {
		fmt.Fprintf(os.Stdout, "error writing numStations")
		return false
	}

	fmt.Printf(" sending WELCOME; expecting SET_STATION\n")
	return true
}

func sendAnnounce(conn *net.TCPConn, songname string) bool {
	var replyType uint8 = 1
	var songnameSize uint8 = uint8(len(songname))
	var songnameChar = []byte(songname)

	err := binary.Write(conn, binary.BigEndian, replyType)
	if err != nil {
		fmt.Fprintf(os.Stdout, "error writing replyType")
		return false
	}

	err = binary.Write(conn, binary.BigEndian, songnameSize)
	if err != nil {
		fmt.Fprintf(os.Stdout, "error writing songnameSize")
		return false
	}

	err = binary.Write(conn, binary.BigEndian, songnameChar)
	if err != nil {
		fmt.Fprintf(os.Stdout, "error writing songname")
		return false
	}
	return true

}

func sendInvalidCommand(conn *net.TCPConn, contentStr string) bool {
	var replyType uint8 = 2

	var replyStringSize uint8 = uint8(len(contentStr))
	replyString := []byte(contentStr)

	err := binary.Write(conn, binary.BigEndian, replyType)
	if err != nil {
		//fmt.Fprintf(os.Stdout, "error writing replyType")
		return false
	}

	err = binary.Write(conn, binary.BigEndian, replyStringSize)
	if err != nil {
		//fmt.Fprintf(os.Stdout, "error writing replyStringSize")
		return false
	}

	err = binary.Write(conn, binary.BigEndian, replyString)
	if err != nil {
		//fmt.Fprintf(os.Stdout, "error writing replyString")
		return false
	}
	return true
}

func removeClient(server *ServerInfo, address string, port uint16, sessionid int) {
	fmt.Printf("session id %2d: client closed connection\n", sessionid)
	for i := 0; i < server.numStations; i++ {
		server.stations[i].lock.Lock()
	}
	var stationIdx int
	var ptr, prev *ClientInfo
	for stationIdx = 0; stationIdx < server.numStations; stationIdx++ {
		ptr = server.stations[stationIdx].head
		prev = nil
		clientFound := false
		for ; ptr != nil; ptr = ptr.next {
			if ptr.address == address && ptr.udpport == port {
				clientFound = true
				break
			}
			prev = ptr
		}
		if clientFound {
			break
		}
	}
	if ptr == nil {
		return
	}
	if prev != nil {
		prev.next = ptr.next
	} else {
		server.stations[stationIdx].head = ptr.next
	}
	server.stations[stationIdx].numClients -= 1
	ptr.controlConn.Close()
	ptr.listenerConn.Close()
	for i := 0; i < server.numStations; i++ {
		server.stations[i].lock.Unlock()
	}

}

func switchStation(server *ServerInfo, from int, to int, client *ClientInfo) {
	if from == to || from >= server.numStations || to >= server.numStations || from < 0 || to < 0 {
		return
	}
	server.stations[from].lock.Lock()
	server.stations[to].lock.Lock()
	src := &server.stations[from]
	dest := &server.stations[to]

	var ptr, prev *ClientInfo = nil, nil
	for ptr = src.head; ptr != client; ptr = ptr.next {
		prev = ptr
	}
	if ptr == nil {
		return
	}
	if prev != nil {
		prev.next = client.next
	} else {
		src.head = client.next
	}
	src.numClients -= 1
	client.next = dest.head
	dest.head = client
	dest.numClients += 1

	server.stations[from].lock.Unlock()
	server.stations[to].lock.Unlock()
}

func handleConnection(server *ServerInfo, conn *net.TCPConn, sessionId int) {
	fmt.Println("new connection from ", conn.RemoteAddr())
	var currClient ClientInfo
	var udpport uint16
	if !getHello(conn, &udpport) {
		fmt.Printf("session id %2d: client closed connection[no handshake]\n", sessionId)
		return
	}
	fmt.Printf("session id %2d: received HELLO with udpport = %d;", sessionId, udpport)
	if !sendWelcome(conn, server.numStations) {
		fmt.Printf("session id %2d: client closed connection\n", sessionId)
		return
	}
	var stationNo int
	if !getSetStation(conn, &stationNo, server.numStations) {
		fmt.Printf("session id %2d: client closed connection\n", sessionId)
		return
	}
	fmt.Printf("session id %2d: received SET_STATION with stationNumber = %d\n", sessionId, stationNo)
	currClient.udpport = udpport
	currClient.controlConn = conn
	currClient.listenerConn = nil
	currClient.address = strings.Split(conn.RemoteAddr().String(), ":")[0]
	if !sendAnnounce(conn, server.stations[stationNo].filename) {
		return
	}
	server.stations[stationNo].lock.Lock()
	currClient.next = server.stations[stationNo].head
	server.stations[stationNo].head = &currClient
	server.stations[stationNo].numClients += 1
	server.stations[stationNo].lock.Unlock()
	srcStation := stationNo
	for {
		var commandType uint8
		var stationNo uint16
		err := binary.Read(conn, binary.BigEndian, &commandType)
		if err != nil {
			removeClient(server, currClient.address, currClient.udpport, sessionId)
			return
		}
		if commandType != 1 {
			sendInvalidCommand(currClient.controlConn, "clientInteract: invalid commandType")
			removeClient(server, currClient.address, currClient.udpport, sessionId)
			return
		}
		err = binary.Read(conn, binary.BigEndian, &stationNo)
		if err != nil {
			fmt.Fprintf(os.Stdout, "receiving stationNo error\n")
			removeClient(server, currClient.address, currClient.udpport, sessionId)
			return
		}
		destStation := int(stationNo)
		if srcStation != destStation {
			switchStation(server, srcStation, destStation, &currClient)
			srcStation = destStation
		}
		if !sendAnnounce(conn, server.stations[srcStation].filename) {
			return
		}

	}

}

func serverInputHandler(server *ServerInfo) {
	reader := bufio.NewReader(os.Stdin)
	for {
		text, _ := reader.ReadString('\n')
		textStr := []byte(text)
		if textStr[0] == byte('p') {
			printServerInfo(server)
		} else if textStr[0] == byte('q') {
			fmt.Printf("server closing connection\n")
			os.Exit(1)
		}
	}
}

func playStation(station *StationInfo) {

	var buf = make([]byte, UDP_PACKET_SIZE)
	var tailBuf = make([]byte, UDP_PACKET_SIZE)
	for {
		lastBuffer := false
		startTime := time.Now()
		station.lock.Lock()
		numRead, err := station.fp.Read(buf)
		toAnnounce := false
		if numRead < len(buf) || err != nil {

			lastBuffer = true
			copy(tailBuf[0:numRead], buf[0:numRead])
			station.fp.Seek(0, 0)
			numRead, _ = station.fp.Read(buf)
			toAnnounce = true
		}
		for client := station.head; client != nil; client = client.next {
			if toAnnounce {
				sendAnnounce(client.controlConn, station.filename)
			}
			udpAddrStr := client.address + ":" + strconv.Itoa(int(client.udpport))
			service, err := net.ResolveUDPAddr("udp", udpAddrStr)
			checkError(err)
			if client.listenerConn == nil {
				client.listenerConn, err = net.DialUDP("udp", nil, service)
				if err != nil {
					checkError(err)
					client.listenerConn = nil
					continue
				}
			}
			if lastBuffer {
				binary.Write(client.listenerConn, binary.BigEndian, tailBuf[0:numRead])

			}
			binary.Write(client.listenerConn, binary.BigEndian, buf)

		}
		station.lock.Unlock()
		endTime := time.Now()

		time.Sleep(62500*time.Microsecond - endTime.Sub(startTime) - 2000*time.Microsecond)
	}
}

func main() {
	var server ServerInfo
	initServer(&server)
	setTcpConn(&server)
	go serverInputHandler(&server)
	for i := 0; i < server.numStations; i++ {
		//fmt.Printf("i=%d\n", i)
		go playStation(&server.stations[i])
	}
	for {
		conn, err := server.listener.AcceptTCP()
		if err != nil {
			continue
		}
		server.numClients += 1
		go handleConnection(&server, conn, server.numClients)
	}
}

func checkError(err error) {
	if err != nil {
		fmt.Fprintf(os.Stderr, "fatal error: %s\n", err.Error())
		os.Exit(1)
	}
}
