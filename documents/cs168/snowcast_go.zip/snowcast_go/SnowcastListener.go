/* snowcast_listener
 */
package main

import (
	"bufio"
	"fmt"
	"net"
	"os"
	"snowcast_util"
	"strconv"
)

const MAXBUFLEN int = 2000

func parseArgument(argv []string) int {
	if len(argv) != 2 || !snowcast_util.IsNumber(argv[1]) {
		fmt.Fprintf(os.Stderr, "Usage: %s <udpport>\n", os.Args[0])
		os.Exit(1)
	}
	port := snowcast_util.StrToPort(argv[1])
	if port < 0 || port > 65535 {
		fmt.Fprintf(os.Stderr, "udpport must be in [0,65535]\n")
		os.Exit(1)
	}
	return port
}

func main() {

	service := ":" + strconv.Itoa(parseArgument(os.Args))

	udpAddr, err := net.ResolveUDPAddr("udp4", service)
	checkError(err)

	conn, err := net.ListenUDP("udp", udpAddr)
	checkError(err)

	for {
		handleClient(conn)
	}

}

func handleClient(conn *net.UDPConn) {
	var buf [MAXBUFLEN]byte
	numread, _, err := conn.ReadFromUDP(buf[0:])
	if err != nil {
		return
	}
	f := bufio.NewWriter(os.Stdout)
	defer f.Flush()
	_, err = f.Write(buf[0:numread])
	if err != nil {
		return
	}

}

func checkError(err error) {
	if err != nil {
		fmt.Fprintf(os.Stderr, "fatal error: %s\n", err.Error())
		os.Exit(1)
	}
}
